require(['head','menu','base','tab','page', 'calendar', 'status'],
    function(){
        M.define('financingTwo',{
            head:M.ui.head.init(),
            init:function(){
                M.ui.menu.init({
                    index:[],
                    url:M.getNormalPath('getMenu.json',4),
                    callback: function() {
                    }
                });
                this.base = M.static.init();
                // this.loanDate = '';
                this.financingOne = own.fetch('finacingOne');
                this.selectIds = '';
                this.isSpaned = false;
                this.totalServiceFee = 0;
                //判断是否为第一次加载，默认选中第一个金融机构
                this.isFirstReload = true;

                this.isSubmit = false;  //解决重复提交问题
                this.orgList = [];
                this.getDate();
                this.getTableData();

                this.tableDataArray = [];
            },

            initOrgEvents: function() {

                $('.ui-other-bank-btn').unbind('click').bind('click',M.financingTwo.otherBank);//显示更多放款机构
                $('.ui-newReport-section-right li').unbind('click').bind('click',M.financingTwo.checkLi);//选择放款机构
                $('.ui-newReport-section-right li').unbind('mouseover').bind('mouseover',M.financingTwo.enterLi);//鼠标滑入放款机构提示信息位置判断
                // $('.with-price-btn').bind('click',M.financingTwo.withPrice);//试算费用
                $('.with-price-btn').unbind('click').bind('click',function (e) {
                    e.preventDefault();
                    e.stopPropagation();
                    var name=$(this).attr('data-name'),org=$(this).attr('data-org')
                    M.financingTwo.getApplyTrial(name,org, M.financingTwo.isFirstReload);
                    $(this).parents('li').addClass('is-ready')
                    $(this).hide()
                })
                $('.with-price-btn').eq(0).click();
                M.financingTwo.isFirstReload = false;
            },

            /*选择机构相关函数*/

            enterLi:function(){
                var offsetTop=$(this)[0].getBoundingClientRect().top;
                var innerHeight=document.documentElement.clientHeight || document.body.clientHeight;
                if(innerHeight/2-66<offsetTop){
                    $(this).addClass('down')
                }else{
                    $(this).removeClass('down')
                }
            },
            checkLi:function(e){

                // e.preventDefault();
                e.stopPropagation();
                if($(this).hasClass('is-ready')){
                    $(this).addClass('active').siblings().removeClass('active');
                }else{
                    M.ui.waiting.creat({
                        status:false,
                        text:'请先试算费用！',
                        time:3000
                    })
                }

                var index=$(".afford-org li").index(this);
                M.financingTwo.selectOrgAt(index);
            },
            otherBank:function(){
                $('.ui-other-bank-btn').hide();
                $('.ui-newReport-section-right li').show();
            },

            getDate: function(){

                var that = this;

                var selectIds = [];
                for (var i = 0; i < this.financingOne.listFinancing.length; i++) {
                    selectIds.push(this.financingOne.listFinancing[i].id);
                }
                this.selectIds = selectIds.join(',');

                M('#confirmSubmit').unbind('click').bind('click', function (ev) {
                    var isSubmit = M.financingTwo.isSubmit;
                    if (!isSubmit) {
                        var flag = M('#confirmSubmit').hasClass('hightlight');
                        if (flag) {
                            M.financingTwo.submitClick();
                        } else {
                            M.ui.status.init({
                                position: 'fixed',
                                html: '该笔融资中部分通宝暂不支持财务公司融资，请选择其他金融机构，若有问题可咨询对口客户经理或95025',
                                callback: function() {
                                }
                            });
                        }
                    }
                });

                M.ajaxFn({
                    url: M.interfacePath.bill + 't/earliest/maturityDate',
                    type: 'post',
                    data: {
                        ids: selectIds
                    },
                    dataType: 'json',
                    contentType: 'application/json',
                    success: function (data) {
                        if ( data.success ) {
                            var maxDate = data.data;

                            var curDate = new Date(maxDate);
                            var prevTime = new Date(curDate.getTime() - 24*60*60*1000);
                            var prevDate = M.timetrans(prevTime);

                            var calenderStart = M.ui.calendar.init({
                                target: M('#js-calender-start'),
                                date: {
                                    format: 'YYYY-MM-DD',
                                    min: 'now',
                                    max: prevDate
                                },
                                time: {
                                    enabled: false
                                },
                                number: 1,
                                toggle: 1,
                                relative: {
                                    type: 'stop'
                                },
                                tool: {
                                    clear: true,
                                    today: true
                                },
                                callback: function (that) {
                                },
                                choose: function (e) {
                                    e.loadDateValid();
                                }
                            }, that);

                            that.initFundDate();
                        }else {
                            M.ui.waiting.creat({
                                status:false,
                                time:1000,
                                text:data.message,
                                hide:false,
                            });
                        }
                    },
                    error: function (res) {

                    }
                });
            },

            //判断放款日期是否为工作日
            loadDateValid: function() {
                var that = this;
                M.ajaxFn({
                    url: M.interfacePath.bill + 't/currntTime/isWorkDay',
                    type: 'post',
                    data: {
                        date: M('#js-calender-start').val()
                    },
                    dataType: 'json',
                    contentType: 'application/json',
                    success: function (data) {
                        if ( data.success ) {
                            that.getFinanceOrgList();
                        }else {
                            M('#js-calender-start').val('');
                            M.ui.waiting.creat({
                                status:false,
                                time:1000,
                                text:data.message,
                                hide:false,
                            });
                        }
                    },
                    error: function (res) {

                    }
                });
            },

            selectOrgAt: function(index) {
                var list = M.financingTwo.orgList;
                if (!list || list.length == 0) {
                    return;
                }

                var item = list[index];
                var bankNum = item.finOrgNo;

                var detailList = item.detailList;

                var flag = true;

                //是否存在多家开立方
                var isVarKai = false;
                var kailiOrg = '';

                M('.table .table-tr').each(function () {

                    var billNum = M(this).children('.bill-num').html();

                    for (var i = 0; i < detailList.length; i++) {

                        var subItem = detailList[i];
                        if (subItem.ownRecordId == billNum) {
                            M(this).children('.lixi-num').html(M.getFormatNumber(subItem.bankFeeRate * 100,4));
                            M(this).children('.xifei-num').html(M.getFormatNumber(subItem.bankFee));
                            M(this).children('.fuwufeilv-num').html(M.getFormatNumber(subItem.financingServiceFeeRate * 100,4));
                            M(this).children('.fuwufei-num').html(M.getFormatNumber(subItem.financingServiceFee));

                            var result = M.financingTwo.isOrgAndFisrtHand(this, bankNum);
                            if (!result && flag) {
                                flag = false;
                            }

                            // if (kailiOrg.length == 0) {
                            //     kailiOrg = M(this).children('.create-side').html();
                            // } else {
                            //     if (kailiOrg != M(this).children('.create-side').html() && !isVarKai) {
                            //         isVarKai = true;
                            //     }
                            // }
                        }
                    }
                })

                // M.financingTwo.setOrgAndFirstStatus(flag&&!isVarKai);
                M.financingTwo.setOrgAndFirstStatus(flag);

            },

            //是否为放款机构
            isOrgAndFisrtHand: function(tr, bankNum) {

                var flag = $(tr).attr('detail-first');

                if (bankNum == M.interfacePath.financingOrgCode && flag != "1") {
                    M(tr).addClass('unable');
                    return false;
                } else {
                    M(tr).removeClass('unable');
                    return true;
                }

            },

            //融资机构提示语
            changeTips: function(bankNum, index) {
                // var notice = '';
                // if (bankNum == M.interfacePath.financingOrgCode) {
                //     notice = "1.因各放款机构的计息规则有所不同，平台显示的放款金额、息费等仅为试算金额，实际金额以放款机构公布为准。若融资遇到问题，请联系对口客户经理或95025进行咨询。<p style='margin-left: 24px;'>2.申请完成后需下载财务公司宝财GO APP， 完成后续融资操作，点击<a id='test' href='../res/data/财务公司宝财GO 安装指南.doc' target='_blank'>财务公司宝财GO</a>下载操作提示。</p><p style='margin-left: 24px;'>3.若该笔融资申请中含多家核心企业通宝，请分别点选发起融资。</p>";
                //     // M('.notice-con').html(notice);
                // } else {
                //     notice = "因各放款机构的计息规则有所不同，平台显示的放款金额、息费等仅为试算金额，实际金额以放款机构公布为准。若无法选择放款机构，请联系客服95025进行咨询。";
                //     // M('.notice-con').html(notice);
                // }
                // return notice;
                M.ajaxFn({
                    url: M.interfacePath.bill + 't/nologin/getValueByGroupAndCode',
                    type: 'post',
                    data: {
                        "setGroup":"FINANCING_ORG_TIPS",
                        "code":bankNum
                    },
                    dataType: 'json',
                    contentType: 'application/json',
                    success: function (data) {
                        if ( data.success ) {
                            var tips = data.data;
                            var element = '.afford-org .institue:eq('+ index +')';
                            M(element).children('.ui-newReport-hover-pop').children('.icon-tips').html(tips);
                        }
                    },
                    error: function (res) {

                    }
                });
            },

            setOrgAndFirstStatus: function(flag) {
                if (!flag) {
                    M('#prev-step').addClass('hightlight');
                    M('#confirmSubmit').removeClass('hightlight');
                    // M('#confirmSubmit').unbind('click');
                } else {
                    M('#prev-step').removeClass('hightlight');
                    M('#confirmSubmit').addClass('hightlight');
                    // M('#confirmSubmit').unbind('click').bind('click', function (ev) {
                    //     var isSubmit = M.financingTwo.isSubmit;
                    //     if (!isSubmit) {
                    //         M.financingTwo.submitClick();
                    //     }
                    // });
                }
            },


            //初始化放款日期
            initFundDate: function() {

                var end = new Date().getHours();

                var now = M.currentDate();

                if (end > 13 ) {
                    var curDate = new Date();
                    var nextDate = new Date(curDate.getTime() + 24*60*60*1000);
                    now = M.timetrans(nextDate);
                }

                this.initloadDateValid(now);
                // this.loanDate = now;
            },

            //初始判断是不是工作日
            initloadDateValid: function(date) {
                var that = this;
                M.ajaxFn({
                    url: M.interfacePath.bill + 't/currntTime/isWorkDay',
                    type: 'post',
                    data: {
                        date: date
                    },
                    dataType: 'json',
                    contentType: 'application/json',
                    success: function (data) {
                        if ( data.success ) {
                            M('#js-calender-start').val(date);
                            M.financingTwo.getFinanceOrgList();
                        }else {
                            that.nextWorkDay(date);
                        }
                    },
                    error: function (res) {

                    }
                });
            },

            //获取最近一天的工作日
            nextWorkDay: function(date) {
                M.ajaxFn({
                    url: M.interfacePath.basic + 't/nextWorkDay',
                    type: 'post',
                    data: {
                        date: date,
                        n: '1',
                        format: 'yyyy-MM-dd'
                    },
                    dataType: 'json',
                    contentType: 'application/json',
                    success: function (data) {
                        if ( data.success ) {
                            M('#js-calender-start').val(data.data);
                            M.financingTwo.getFinanceOrgList();
                        }else {

                        }
                    },
                    error: function (res) {

                    }
                });
            },

            //获取通宝列表
            getTableData: function () {
                M.ajaxFn({
                    url: M.interfacePath.bill + 't/financing/getBillDetailByIds',
                    type: 'post',
                    data: {
                        "bills": M.financingTwo.financingOne.listFinancing,
                        "pageSize": 100
                    },
                    dataType: 'json',
                    contentType: 'application/json',
                    success: function (data) {
//                        console.log(data);
                        M.financingTwo.totalServiceFee = data.data.totalServiceFee;

                        var str =   '<div class="table-th">' +
                            '<div class="bill-num">通宝编号</div>' +
                            '<div class="create-side">开立方</div>' +
                            '<div class="cash-date">兑付日期</div>' +
                            '<div class="have-num">持有金额</div>' +
                            '<div class="fin-num">融资金额</div>' +
                            '<div class="fin-num">金融机构利率（%）</div>' +
                            '<div class="fin-num">息费</div>' +
                            '<div class="fin-num">服务费率（%）</div>' +
                            '<div class="fin-num">服务费</div>' +
                            '</div>';
                        for (var i = 0; i < data.data.dataList.length; i++) {
                            var item = data.data.dataList[i];
                            var ddd = M.timetrans(item.maturityDate);
                            str += '<div class="table-tr" detail-first="' + item.firstHand + '">' +
                                        '<div class="bill-num">'+ item.billHoldNo +'</div>' +
                                        '<div class="create-side nameTxt"><span title="'+ item.payerName +'">' + item.payerName + '</span></div>' +
                                        '<div class="cash-date">' + ddd + '</div>' +
                                        '<div class="have-num">' + M.getFormatNumber(item.holdAmount) + '</div>' +
                                        '<div class="fin-num">' + M.getFormatNumber(item.applyAmount) + '</div>' +
                                        '<div class="lixi-num"></div>' +
                                        '<div class="xifei-num"></div>' +
                                        '<div class="fuwufeilv-num"></div>' +
                                        '<div class="fuwufei-num"></div>' +
                                    '</div>';
                        }
                        var serviceFeeRate = data.data.serviceFeeRate || "";

                        M('.table').html(str);
                        M('.total-num').html(M.getFormatNumber(data.data.totalApplyAmount) || "");
                        if (parseFloat(data.data.totalServiceFee) == 0){
                            M('.service_des').html("");
                        } else {
                            M('.service-fee').html(M.getFormatNumber(data.data.totalServiceFee) || "");
                        }
                    },
                    error: function (res) {
                        console.log(res);
                    }
                });
            },

            //获取金融机构
            getFinanceOrgList: function () {
                var that = this;
                M.ajaxFn({
                    url: M.interfacePath.bill + 't/financing/selectableFinanceOrgList',
                    type: 'post',
                    data: {
                        "ids": M.financingTwo.selectIds,
                    },
                    dataType: 'json',
                    contentType: 'application/json',
                    success: function (data) {
                        if(data.success){
                            if(data.data.length>3){
                                $(".ui-other-bank-btn").show()
                            }
                            //console.log(data);
                            M.financingTwo.orgList = data.data;

                            var str = '';
                            for (var i = 0; i < data.data.length; i++) {

                                var item = data.data[i];
                                var image = '../res/images/base/'+ item.finOrgNo +'.png';
                                var active = i == 0 ? ' active' : '';
                                var bss=i == 0 ? ' bss' : '';
                                var showStr = i > 2 ? ' style="display:none;"' : '';
                                // str +=  '<li class="institue' + active + '">' +
                                //             '<img class="logo" src="' + image + '" alt="">' +
                                //             '<div class="gap"></div>' +
                                //             '<div class="sent-info">' +
                                //                 '<div class="sent-head">放款金额</div>' +
                                //                 '<div class="sent-num">计算中...</div>' +
                                //                 '<div class="interest"><i></i>利息&nbsp;<span class="inter-num">000.00</span></div>' +
                                //                 '<div class="interest"><i></i>服务费&nbsp;<span class="service-num">000.00</span></div>' +
                                //             '</div>' +
                                //             '<i class="iconfont">&#xe74c;</i>' +
                                //         '</li>';
                                str+='<li class="institue' + active + '"' + showStr + '>\n' +
                                    '    <img src="../res/images/base/newReport-selected.png" alt="" class="section-right-selected i-img">\n' +
                                    '    <img src="../res/images/base/newReport-select.png" alt="" class="section-right-select i-img">\n' +
                                    '    <div class="section-right-box-one">\n' +
                                    '        <div class="section-right-box-sec with-logo">\n' +
                                    '            <img src="' + image + '" alt="" class="ui-newReport-section-bank-icon"> <span class="ui-newReport-section-bank-name">'+'</span>\n' +
                                    '            <span class="ui-newReport-iconfont-box"><i class="iconfont">&#xe66e;</i></span>\n' +
                                    '        </div>\n' +
                                    '        <div class="section-right-box-sec with-price">\n' +
                                    '            <div class="with-price-btn' + bss + '" data-name="'+item.finOrgName+ '" data-org="'+item.finOrgNo+ '">试算费用</div>\n' +
                                    '            <span class="font14">放款金额</span> <span class="font20 i-ita sent-num">--</span> <span class="font14">元</span>\n' +
                                    '            <div class="clear"></div>\n' +
                                    '        </div>\n' +
                                    '        <div class="section-right-box-sec with-sum">\n' +
                                    '            <span class="txt"><i class="iconfont">&#xe60c;</i>服务费：<span class="service-num">--</span></span>&nbsp;&nbsp;&nbsp;&nbsp;<span class="txt"><i class="iconfont">&#xe60c;</i>利息：<span class="inter-num">--</span></span>\n' +
                                    '        </div>\n' +
                                    '    </div>\n' +
                                    '    <img src="../res/images/base/newReport-pop-arrow.png" alt="" class="newReport-pop-arrow">\n' +
                                    '    <img src="../res/images/base/newReport-pop-arrow-down.png" alt="" class="newReport-pop-arrow-down">\n' +
                                    '    <span class="ui-newReport-hover-pop">\n' +
                                    '                <span class="icon-tips"></span>\n' +
                                    '            </span>\n' +
                                    '</li>'

                                M.financingTwo.changeTips(item.finOrgNo, i);
                                M.financingTwo.getOrgName(item.finOrgName, i);
                            }
                            //调取试算接口
                            M('.afford-org').html(str);
                            M.financingTwo.initOrgEvents();

                            // that.layoutFinOrg.bind(that)();
                        }else{
                            M.ui.waiting.creat({
                                status:false,
                                time:1000,
                                text:data.message,
                                hide:false
                            });
                            return;
                        }

                    },
                    error: function (res) {
                        console.log(res);
                    }
                });
            },

            //获取金融机构简称
            getOrgName: function(orgName, index) {
                M.ajaxFn({
                    url: M.interfacePath.bill + 't/nologin/getValueByGroupAndCode',
                    type: 'post',
                    data: {
                        "setGroup":"FINANCING_ORG_NAME",
                        "code": orgName
                    },
                    dataType: 'json',
                    contentType: 'application/json',
                    success: function (data) {
                        if (data.success) {
                            M('.ui-newReport-section-bank-name').eq(index).html(data.data);
                        }else {
                            M.ui.waiting.creat({
                                status:false,
                                time:1000,
                                text:data.message,
                                hide:false
                            });
                        }
                    },
                    error: function (res) {
                        console.log(res);
                    }
                });
            },

            //获取试算接口
            getApplyTrial: function (name,finOrgNo, needSelect) {

                var loanDate = M('#js-calender-start').val();

                M.ajaxFn({
                    url: M.interfacePath.bill + 't/financing/applyTrialResult',
                    type: 'post',
                    data: {
                        "bills": M.financingTwo.financingOne.listFinancing,
                        "financeOrgName": name,
                        "financeOrg": finOrgNo,
                        "loanDate": loanDate
                    },
                    dataType: 'json',
                    contentType: 'application/json',
                    success: function (data) {
//                        console.log(data);

                        if (data.success) {
                            var orgList = M.financingTwo.orgList;
                            var totalServiceFee = M.financingTwo.totalServiceFee;

                            for (var i = 0; i < orgList.length; i++) {
                                var item = orgList[i];
                                if (item.finOrgName == name) {
                                    item.detailList = data.data.dataList;
                                    item.totalBillAmount = data.data.totalBillAmount;
                                    item.totalBillMoney = data.data.totalBillMoney;
                                    item.totalPayAmount = data.data.totalPayAmount;
                                    item.totalInterest = data.data.totalInterest;

                                    var institueEl = M('.afford-org').children('.institue').eq(i);

                                    M(institueEl).find('.sent-num').html(M.getFormatNumber(data.data.totalPayAmount));
                                    M(institueEl).find('.inter-num').html(M.getFormatNumber(data.data.totalBankFee));
                                    M(institueEl).find('.service-num').html(M.getFormatNumber(data.data.totalFinancingServiceFee));
                                    M(institueEl).find('.ser-num').html(M.getFormatNumber(totalServiceFee));

                                }


                            }

                            needSelect && M.financingTwo.selectOrgAt(0);
                        }  else  {
                            var message = data.message;
                            M('.ui-dialog-upload').hide();
                            M('.ui-dialog-errortips').show();
                            M('.ui-dialog-errortips-p').html(message);
                            M('.ui-errortips-btn').bind('click', function () {
                                M('.ui-dialog-upload').show();
                                M('.ui-dialog-errortips').hide();
                            })
                            M.ui.waiting.creat({
                                status:false,
                                time:1000,
                                text:message,
                                hide:false
                            });
                            return;
                        }

                    },
                    error: function (res) {
                        console.log(res);
                    }
                });
            },


            //融资机构排列
            layoutFinOrg: function() {
                var that = this;
                var orgList = M.financingTwo.orgList;
                if (orgList.length > 2) {
                    M('.spaned').show();
                    M('.spaned').removeClass('jiantou-up').addClass('jiantou-down');
                    M('.afford-org li:gt(1)').hide();
                    M('.spaned').unbind('click').bind('click', function () {
                        var isSpaned = that.isSpaned;
                        if (isSpaned) {
                            M('.spaned').removeClass('jiantou-up').addClass('jiantou-down');
                            M('.afford-org li:gt(1)').hide();
                        }  else  {
                            M('.spaned').removeClass('jiantou-down').addClass('jiantou-up');
                            M('.afford-org>li').show();
                        }
                        that.isSpaned = !isSpaned;
                    })
                }
            },


            //提交接口
            submitClick: function () {

                var isSubmit = M.financingTwo.isSubmit;

                if (isSubmit) {
                    return;
                }

                M.financingTwo.isSubmit = true;

                var loanDate = M('#js-calender-start').val();

                if (!loanDate || loanDate.length === 0) {
                    M.ui.status.init({
                        drag: false,
                        title:'提示',
                        html:"请选择放款日期",
                    },this);
                    M.financingTwo.isSubmit = false;
                    return;
                }

                var orgList = M.financingTwo.orgList;
                if (orgList.length === 0) {
                    return;
                }
                var selectIndex = 0;
                M('.afford-org').children('.institue').each(function(index, element){
                    if (M(this).is('.active')){
                        selectIndex = index;
                        return;
                    }
                });

                var institue = orgList[selectIndex];
                if (!institue.detailList || institue.detailList.length === 0) {
                    M.financingTwo.isSubmit = false;
                    return;
                }

                M.ajaxFn({
                    url: M.interfacePath.bill + 't/financing/saveFinancingApply',
                    type: 'post',
                    data: {
                        "financialInstitutionsId": institue.finOrgNo,
                        "financialInstitutionsName": institue.finOrgName,
                        "loanDate": loanDate,
                        "detailList": institue.detailList,
                    },
                    dataType: 'json',
                    contentType: 'application/json',
                    async: false,
                    success: function (data) {
                     //   console.log(data);
                        if (data.success) {
                            var applicationId = data.data;
                           //  if (applicationId) {
                           //
                           //      var url = "financingConfirm.html?applicationId=" + applicationId;
                           //
                           //      var el = document.createElement("a");
                           //      document.body.appendChild(el);
                           //      el.href = url; //url 是你得到的连接
                           //      el.target = '_blank'; //指定在新窗口打开
                           //      el.click();
                           //      // document.body.removeChild(el);
                           //  }
                           //
                           // window.location.href = "financingList.html";

                            if(applicationId) {
                                 var url = "financingThree.html?applicationId=" + applicationId;
                                 window.location.href = url;
                            }

                        } else {
                            var message = data.message;
                            M('.ui-dialog-upload').hide();
                            M('.g-master-container').show();
                            M('.ui-dialog-errortips-p').html(message);
                            M('.ui-errortips-btn').bind('click', function () {
                                M('.ui-dialog-upload').show();
                                M('.g-master-container').hide();
                            })
                        }

                        M.financingTwo.isSubmit = false;
                    },
                    error: function (res) {
                        M.financingTwo.isSubmit = false;
                        console.log(res);
                    }
                });

            },

        })(function(){
            M.financingTwo.init();
        });
    }
)
