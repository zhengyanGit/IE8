require(['head', 'menu', 'base', 'tab', 'page', 'calendar', 'status', 'confirm','customDialog','plupload','fuzzy'],
    function () {
        M.define('billIssueReceipt', {
            head: M.ui.head.init(),
            init: function () {
                M.ui.menu.init({
                    index: [0, 3],
                    url: M.getNormalPath('getMenu.json', 4),
                    callback: function () {

                    }
                });

                var menuId = M.getMenuId('../bill/checkInvoice.html');
                this.count = 10;
                this.timer="";
                this.getBtnPrivilege(menuId)

                this.invoiceStatus="";
                this.base = M.static.init();
                this.status = 10;
                this.pageSize = 10;
                this.isSearch = true;
                this.getData();
                this.getTableData(1);
                this.queryData();
                this.contracts=[];
                M('#refreshtitle').html('('+ 10 + 'S)自动刷新列表');
                M.billIssueReceipt.countDown()
            },

            getBtnPrivilege: function(menuId) {
                M.buttonsPrivilege(menuId, function (data) {
                    if (!data || data.length == 0){
                        return;
                    }
                    for (var i = 0; i<data.length; i++) {
                        if (data[i].btnNo == "DRYP01") {
                            M('#openbillexc').after('<a id="exportExcel" href="javascript:;" class="ui-button-ghost g-nav-btn ui-btn-red"><i class="iconfont mar-right-5">&#xe67b;</i>Excel导入</a>');
                            //批量导入
                            M('#exportExcel').on('click', function() {
                                M.billIssueReceipt.exportExcel();
                            })
                        }
                    }
                })
            },

            //导入Excel
            exportExcel: function () {
                M.ui.customDialog.init({
                    drag:false,
                    title:'导入Excel',
                    width:480,
                    height:200,
                    autoClose:false,
                    url:'../dialog/dialog-excelImport.html',
                    callback:function(e){
                        var title="导入Excel"
                        $('.ui-dialog-title').html(title)
                        $('#loadNeed').attr('href',"../res/data/checkInvoice.xlsx")
                        //上传图片
                        var uploader = new plupload.Uploader({ //实例化一个plupload上传对象
                            browse_button : 'browse',//上传ID
                            headers:{
                                'Authorization': own.fetch('userInfo').token
                            },
                            url :  M.interfacePath.assetsUpload,
                            runtimes: 'gears,html5,html4,silverlight,flash',
                            flash_swf_url : '../../../../base/js/core/Moxie.swf',
                            silverlight_xap_url : '../../../../base/js/core/Moxie.xap',
                            multi_selection: false,
                            filters: {
                                mime_types : [ //只允许上传图片和zip文件
                                    { title : "Document files", extensions : "xls,xlsx" }
                                ],
                                max_file_size : '10485760' //最大只能上传5120kb的文件
                            }
                        });
                        uploader.init(); //初始化

                        uploader.bind('FilesAdded',function(uploader,files){
                            uploader.start();
                        });

                        uploader.bind('Error',function(uploader,errObject){
                            if(errObject.code == -601){
                                M.ui.waiting.creat({
                                    status:false,
                                    time:1000,
                                    text:'不支持该文件类型上传，请重新选择！',
                                    hide:false,
                                });
                            }

                            if(errObject.code == -600){
                                M.ui.waiting.creat({
                                    status:false,
                                    time:1000,
                                    text:'单个文件不能超过10M，请压缩后上传！',
                                    hide:false,
                                });
                            }
                        });
                        uploader.bind('FileUploaded',function(uploader,files,res){
                            var response = res.response.replace("<pre>", "").replace("</pre>", "").replace("<PRE>", "").replace("</PRE>", "").replace(/<[^>]+>/g, "")
                            var data = JSON.parse(response);
                            // console.log(data);
                            if( data.success ) {

                                M.billIssueReceipt. excelCheckInvoice(data.data.fileAddress, e)
                            } else {

                                M.ui.waiting.creat({
                                    status:false,
                                    time:3000,
                                    text:data.message,
                                    hide:false,
                                    callback: function () {
                                        if(data.code.indexOf('TK')>=0){
                                            var codeStr=data.code;
                                            var cod=Number(codeStr.substring(codeStr.indexOf('TK')+2));

                                            if(cod<5){  // 登录超时
                                                own.logout();
                                            }
                                            else if(cod==5){
                                                own.logout();
                                            }
                                            else if(cod==6 || cod==7){  // 无权限
                                                return window.location.href='../basic/500.html';
                                            }
                                        }
                                    }
                                });
                            }
                        });

                        M('.ui-dialog-close').click(function(){
                            e.remove();
                        })
                    }
                })
            },

            excelCheckInvoice: function(fileUrl, e) {
                M.ajaxFn({
                    url:  $.interfacePath.assets +'t/assets/exportCheckInvoice',
                    type: 'post',
                    data: {
                        excelPath: fileUrl
                    },
                    dataType: 'json',
                    success: function (res) {
                        if (res.success){
                            M('.ui-dialog-close').click();
                            M.ui.waiting.creat({
                                position:'fixed',
                                status:'loading',
                                time:500,
                                callback:function(){
                                    M.ui.waiting.creat({
                                        status:true,
                                        time:2000,
                                        text:res.message,
                                        hide:false,
                                        callback:function(){
                                            e.remove();
                                            M.billIssueReceipt.getTableData(1);
                                        }
                                    });
                                }
                            });
                        }else {
                            var message = res.message;
                            M('.ui-dialog-upload').hide();
                            M('.ui-dialog-errortips').show();
                            M('.ui-dialog-errortips-p').html(message);
                            M('.ui-errortips-btn').bind('click', function () {
                                M('.ui-dialog-upload').show();
                                M('.ui-dialog-errortips').hide();
                            })
                        }

                    },
                    error: function (err) {
                        M('.ui-dialog-close').click();
                        console.log('err+'+err)
                    }
                });
            },

            getData: function () {
                var that=this
                M.ui.tab.init({
                    index: 0,
                    button: $('.g-nav-tabs-li'),
                    panel: $('.g-tab-main'),
                    event: 'click',
                    currentClass: 'active',
                    url: null,
                    data: null,
                    callback: function () {
                    },
                    error: function () {
                    }
                });

                /*---------------日历---------------------------------------*/
                var calenderStart = M.ui.calendar.init({
                    target: M('#js-calender-start'),
                    date: {
                        format: 'YYYY-MM-DD'
                    },
                    time: {
                        enabled: false
                    },
                    number: 1,
                    toggle: 1,
                    relative: {
                        type: 'stop'
                    },
                    tool: {
                        clear: true,
                        today: true
                    },
                    callback: function (that) {
                        M.delay(100, function () {
                            this.ops.relative.point = calenderStop;
                        }, this);
                    },
                    choose: function () {
                        //console.log(this);
                    }
                }, this);
                var calenderStop = M.ui.calendar.init({
                    target: M('#js-calender-stop'),
                    date: {
                        format: 'YYYY-MM-DD'
                    },
                    time: {
                        enabled: false
                    },
                    number: 1,
                    toggle: 2,
                    relative: {
                        type: 'start'
                    },
                    tool: {
                        clear: true,
                        today: true
                    },
                    callback: function (that) {
                        M.delay(100, function () {
                            this.ops.relative.point = calenderStart;
                            this.ops.date.min = calenderStart.ops.date.select;
                        }, this);
                    },
                    choose: function () {
                        //console.log(this);
                    }
                }, this);
                var paymentStart = M.ui.calendar.init({
                    target: M('#js-payment-start'),
                    date: {
                        format: 'YYYY-MM-DD'
                    },
                    time: {
                        enabled: false
                    },
                    number: 1,
                    toggle: 1,
                    relative: {
                        type: 'stop'
                    },
                    tool: {
                        clear: true,
                        today: true
                    },
                    callback: function (that) {
                        M.delay(100, function () {
                            this.ops.relative.point = paymentStop;
                        }, this);
                    },
                    choose: function () {
                        //console.log(this);
                    }
                }, this);
                var paymentStop = M.ui.calendar.init({
                    target: M('#js-payment-stop'),
                    date: {
                        format: 'YYYY-MM-DD'
                    },
                    time: {
                        enabled: false
                    },
                    number: 1,
                    toggle: 2,
                    relative: {
                        type: 'start'
                    },
                    tool: {
                        clear: true,
                        today: true
                    },
                    callback: function (that) {
                        M.delay(100, function () {
                            this.ops.relative.point = paymentStart;
                            this.ops.date.min = paymentStart.ops.date.select;
                        }, this);
                    },
                    choose: function () {
                        //console.log(this);
                    }
                }, this);
                /*----------------------------日历结束-----------------------------------------------*/

                //全部
                M('#check_sum').click('on', function () {

                    // clearInterval(that.timer)
                    // that.count=10
                    M.billIssueReceipt.countDown()
                    M.billIssueReceipt.invoiceStatus = "00";
                    M.billIssueReceipt.getTableData(1);

                });
                //验票成功
                M('#check_success').click('on', function () {
                    // clearInterval(that.timer)
                    // that.count=10
                    M.billIssueReceipt.countDown()
                    M.billIssueReceipt.invoiceStatus = "10";
                    M.billIssueReceipt.getTableData(1);

                });
                //验票中
                M('#checking').click('on', function () {
                    // clearInterval(that.timer)
                    // that.count=10
                    M.billIssueReceipt.countDown()
                    M.billIssueReceipt.invoiceStatus = "20";
                    M.billIssueReceipt.getTableData(1);




                });
                //验票失败
                M('#check_fail').click('on', function () {
                    // clearInterval(that.timer)
                    // that.count=10
                    M.billIssueReceipt.countDown()
                    M.billIssueReceipt.invoiceStatus = "30";
                    M.billIssueReceipt.getTableData(1);

                });


                M('.in-tabs').on('click', 'li', function () {
                    M(this).find('a').addClass('active');
                    M(this).siblings().find('a').removeClass('active');

                })

                M('.all-check').on('click', function () {
                    if (M(this).hasClass('active')) {
                        M(this).removeClass('active');
                        M('.billIssue-main-content>tr').removeClass('active');
                    } else {
                        M(this).addClass('active');
                        M('.billIssue-main-content>tr').addClass('active');
                    }
                })
                M('.g-table').on('click', '.table-tr', function (ev) {
                    if (M(this).hasClass('active')) {
                        M(this).removeClass('active');
                    } else {
                        M(this).addClass('active');
                    }
                    var selectedLen=M(this).parent().children("tr.table-tr.active").length
                    var totalLen=M(this).parent().children().length
                    if(selectedLen>=totalLen){
                        M(this).parent().prev().children().children().eq(0).addClass('active')
                    }else{
                        M(this).parent().prev().children().children().eq(0).removeClass('active')
                    }
                });

                M('#downloadSelect').on('click', function() {
                    M.billIssueReceipt.downloadSelect();
                })
                M('#openbillexc').on('click', function() {
                    M.billIssueReceipt.openbillexc();
                })
                M('#checkInvoice').on('click', function() {
                    M.billIssueReceipt.checkInvoice();
                })
                M('#downloadAll').on('click', function () {
                    M.billIssueReceipt.downloadAll();
                })
            },
            countDown:function(){
                var that=this
                that.count=10
                clearInterval(that.timer)
                that.timer = setInterval(function () {
                    that.count--;
                    M('#refreshtitle').html('('+ that.count + 'S)自动刷新列表');
                    if (that.count === 0){
                        that.count=10
                        M.billIssueReceipt.getTableData(1);
                    }

                },1000);
            },
            openbillexc: function() {
                var that = M.billIssueReceipt;
                M.ui.customDialog.init({
                    drag:true,
                    title:'',
                    width:'390',
                    height:'300',
                    autoClose:false,
                    url:'../dialog/dialog-checkInvoice.html',
                    callback:function(e){
                        M('.objection-btn-close').click(function () {
                            e.remove();
                        });

                        var uploader = new plupload.Uploader({ //实例化一个plupload上传对象
                            browse_button : 'browse',//上传ID
                            headers:{
                                'Authorization': own.fetch('userInfo').token,
                            },
                            url :  M.interfacePath.assetsUpload,
                            runtimes: 'gears,html5,html4,silverlight,flash',
                            flash_swf_url : '../../../../base/js/core/Moxie.swf',
                            silverlight_xap_url : '../../../../base/js/core/Moxie.xap',
                            multipart_params: {
                                'Authorization': own.fetch('userInfo').token
                            },
                            filters: {
                                mime_types : [ //只允许上传图片和zip文件
                                    { title : "Image files", extensions : "jpg,png" },
                                    { title : "Zip files", extensions : "zip" },
                                    { title : "Document files", extensions : "pdf" }
                                ],
                                max_file_size : '10485760' //最大只能上传5120kb的文件
                            }
                        });
                        uploader.init(); //初始化
                        uploader.bind('FilesAdded',function(uploader,files){
                            var filesLens = files.length + that.contracts.length;
                            if (that.contracts.length < 1000 && filesLens <= 1000 ) {
                                uploader.start();
                            } else {
                                for (var i=0; i<files.length; i++) {
                                    uploader.removeFile(files[i])
                                }
                                // M.ui.waiting.creat({
                                //     status:false,
                                //     time:1000,
                                //     text:'最多只能上传五个附件',
                                //     hide:false,
                                // });
                            }
                        });
                        uploader.bind('Error',function(uploader,errObject){
                            // console.log(errObject);
                            if(errObject.code == -602){
                                M.ui.waiting.creat({
                                    status:false,
                                    time:1000,
                                    text:'不能选择相同文件！',
                                    hide:false,
                                });
                            }
                            if(errObject.code == -601){
                                M.ui.waiting.creat({
                                    status:false,
                                    time:1000,
                                    text:'不支持该文件类型上传，请重新选择！',
                                    hide:false,
                                });
                            }
                            if(errObject.code == -600){
                                M.ui.waiting.creat({
                                    status:false,
                                    time:1000,
                                    text:'单个文件不能超过10M，请压缩后上传！',
                                    hide:false,
                                });
                            }
                        });
                        uploader.bind('FileUploaded',function(uploader,files,res){
                            var response = res.response.replace("<pre>", "").replace("</pre>", "").replace("<PRE>", "").replace("</PRE>", "").replace(/<[^>]+>/g, "")
                            var data = JSON.parse(response);
                            // console.log(data);
                            if( data.success ) {
                                M.ui.waiting.creat({
                                    position:'fixed',
                                    status:'loading',
                                    time:500,
                                    callback:function(){
                                        M.ui.waiting.creat({
                                            status:true,
                                            time:1000,
                                            text:data.message,
                                            hide:false,
                                        });
                                    }
                                });
                                var invoice = data.data;
                                that.contracts.push({
                                    picPath: invoice.fileAddress,
                                    fileName: invoice.fileName,
                                    fileFormat: invoice.format,
                                    fileSize: invoice.size
                                });
                                var file_name = files.name; //文件名
                                var file_size = data.data.size;
                                //构造html来更新UI
                                M('.uploadBox').addClass('upload-info');
                                var html2 =  '<div class="file-box">'+
                                    '<div class="file-name"><a class="download" href="javascript:;">'+file_name+'</a><a href="javascript:;" class="removeItem">删除</a></div>'+
                                    '<div class="file-size">'+(file_size/1024).toFixed(2)+'k</div>'+
                                    '</div>'
                                $(html2).appendTo('.uploadBox');

                            } else {
                                M.ui.waiting.creat({
                                    status:false,
                                    time:3000,
                                    text:data.message,
                                    hide:false,
                                    callback: function () {
                                        if(data.code.indexOf('TK')>=0){
                                            var codeStr=data.code;
                                            var cod=Number(codeStr.substring(codeStr.indexOf('TK')+2));

                                            if(cod<5){  // 登录超时
                                                own.logout();
        //                                    	localStorage.removeItem("userInfo");
        //                                    	window.location.href=M.interfacePath.server+"/ftb-web/template/basic/login.html";
        //                                         return window.location.href = M.interfacePath.singleLogin;
                                            }
                                            else if(cod==5){
                                                own.logout();
        //                                      window.location.href=M.interfacePath.server+"/ftb-web/template/basic/login.html";
        //                                      return window.location.href = M.interfacePath.singleLogin;
                                            }
                                            else if(cod==6 || cod==7){  // 无权限
                                                return window.location.href='../basic/500.html';
                                            }
                                        }
                                    }
                                });
                            }
                        });
                        // 点击删除
                        $(document).off('click','.removeItem').on('click','.removeItem',function(){
                            var index = $('.uploadBox .removeItem').index($(this));
                            that.contracts.splice(index, 1);
                            $(this).parents('.file-box').remove();
                            if (that.contracts.length == 0) {
                                M('.uploadBox').removeClass('upload-info');
                            }
                        });
                        var flag=false;
                        M("#trueOlad-button").on("click",function(){
                            if (that.contracts.length == 0) {

                                M.ui.waiting.creat({
                                    status:false,
                                    time:1000,
                                    text:'附件不能为空',
                                    hide:false,
                                });
                                return;
                            }
                            if(!flag){
                                flag = true;
                                M.ui.waiting.creat({
                                    status:'loading',
                                    hide:true
                                });
                                var params = that.contracts
                                M.ajaxFn({
                                    url:M.interfacePath.assets+'t/baidu/webOcrCheckFile',
                                    type: 'post',
                                    data: params,
                                    dataType: 'json',
                                    success: function (data) {
                                        M.ui.waiting.dismiss()
                                        if (data.success) {
                                            M.ui.waiting.creat({
                                                status:true,
                                                time:1000,
                                                text:data.message,
                                                hide:false,
                                                callback: function () {
                                                    flag=false;
                                                    e.remove();
                                                    that.contracts=[];
                                                    M.billIssueReceipt.getTableData(1);
                                                }
                                            });
                                        } else {
                                            flag=false
                                            M.ui.waiting.creat({
                                                status:false,
                                                time:1000,
                                                text:data.message,
                                                hide:false,
                                            });
                                        }
                                    },
                                    error: function (err) {
                                        console.log(err)
                                    }
                                })
                            }
                        })
                        M("#validate-save").on("click",function(){
                            that.contracts=[]
                        })
                        M('.ui-dialog-close').click(function(){
                            e.remove();
                        });
                        M('#close').click(function(){
                            e.remove();
                        });
                    }
                });
             },
            queryData:function(){
                M(".all").click(function(){
                    M.billIssueReceipt.status = "";
                    M.billIssueReceipt.getTableData(1);
                });

                M('.ui-search-button').click(function () {
                    M.billIssueReceipt.isSearch = true;
                    M('.date-all').siblings('li').children('a').removeClass('active');
                    M('.date-all').children('a').addClass('active');
                    M.billIssueReceipt.getTableData(1);
                });
            },

            //发票查询列表
            getTableData: function (page,dateSort) {
                // if(M('.all-check').hasClass('active')){
                //     M('.all-check').removeClass('active')
                // }
                var that = this;
                var checkDateStart = M('#js-calender-start').val();
                var checkDateEnd = M('#js-calender-stop').val();
                var status="";
                switch (M.billIssueReceipt.invoiceStatus) {
                    case "00":
                        status="";
                        break;
                    case "10":
                        status="10";
                        break;
                    case "20":
                        status="20";
                        break;
                    case "30":
                        status="30";
                        break;
                    default:
                        status="";
                }

                M.ajaxFn({
                    url: $.interfacePath.assets + 't/assets/webInvoiceList',
                    type: 'post',
                    data: {
                        "pageNum":page,
                        "pageSize":M.billIssueReceipt.pageSize,
                        "checkDateStart":checkDateStart,
                        "checkDateEnd":checkDateEnd,
                        "invoiceStatus":status
                    },
                    dataType: 'json',
                    contentType: 'application/json',
                    success: function (data) {

                        var res = data.data;

                        if (data.success == false || res == null || res.length == 0) {
                            M('.totalAmount').text(0);
                            var noData = '<td colspan="10"><div class="noData"><img src="../../template/res/images/empty.png" alt=""><div class="col60 mar-top-10">暂无记录</div></div></td>';
                            M('.invoice-tbody-content').html(noData);
                            M('.pageTotal').html(data.total);
                            M('.pageCount').html(data.pageCount);
                            M.billIssueReceipt.getPage(data, page, M('#page'));
                        }
                        if(data.success && res !== null && res.length !== 0){
                            var str = '';
                            for (var i = 0; i < res.length; i++) {
                                var item = res[i];
                                if(item.code ===0){
                                  var codeHtml = '<a target="_blank" class="stopEvt" href="billIssueDetail.html?id=' + item.billNo + '">查看详情</a></td>';
                                }
                                if (item.code ==-1){
                                    var codeHtml = '<a id="checkInvoice" href="javascript:;" ><i id="shouyan" class="iconfont mar-right-5">&#xe67b;</i>手工验票</a>';
                                }
                                var resultItem=JSON.parse(item.identifyResult)
                                var needItem='';
                                var invoiceStatus=item.invoiceStatus;
                                var invoiceStatusName='';
                                var invoiceStatusName='';
                                var manualCheckingStr='';
                                var ypinvoiceNumber='';
                                var ypinvoiceCode='';
                                var failMessage='<td class="g-text-center">' + "-" + '</td>';
                                if(resultItem == null){

                                    ypinvoiceCode='<td class="g-text-center">' + '' + '</td>'
                                    ypinvoiceNumber='<td class="g-text-center">' + '' + '</td>'

                                }else{
                                    needItem=resultItem
                                    ypinvoiceCode='<td class="g-text-center">' + needItem.invoiceCode + '</td>'
                                    ypinvoiceNumber='<td class="g-text-center">' + needItem.invoiceNo + '</td>'
                                }

                                if(invoiceStatus=='10'){
                                    invoiceStatusName="验票成功";
                                    manualCheckingStr= '<a href="javascript:;" class="to-details" ' +
                                        'data-code="' + item.invoiceCode + '' +
                                        '" data-number="' + item.invoiceNumber + '' +
                                        '" data-purName="' + item.purchaserName + '" ' +
                                        '" data-salesName="' + item.salesName + '" ' +
                                        '" data-amountTax="' + M.getFormatNumber(item.amountTax, 2, '.', ',') + '" ' +
                                        'data-fileAddress="' + item.fileAddress + '">发票详情</a>';
                                }else if(invoiceStatus=='20'){
                                    invoiceStatusName="验票中";
                                    manualCheckingStr='-';
                                }else if(invoiceStatus=='30'){
                                    invoiceStatusName="验票失败";
                                    manualCheckingStr= '<a href="javascript:;" class="to-checkInvoices" data-invoiceNum="'+needItem.invoiceNo+'" data-invoiceCode="'+needItem.invoiceCode+'" data-creDate="'+needItem.paperDrewDate+'" data-totalAmount="'+needItem.amountWithoutTax+'" data-checkCode="'+needItem.checkCode+'" data-id="' + item.id + '" data-fileAddress="' + item.fileAddress + '">手工验票</a>';
                                    failMessage= '<td class="g-text-center">' + item.msg + '</td>';
                                }


                                str += '<tr class="table-tr" data-id="' + item.id +'">' +

                                    '<td class="g-text-center">' + M.timetrans_hms(item.createDate) + '</td>' +
                                    '<td class="g-text-center">' + M.timetrans_hms(item.updateDate) + '</td>' +
                                    ypinvoiceCode +
                                    ypinvoiceNumber +
                                    '<td class="g-text-center">' + invoiceStatusName + '</td>' +
                                    failMessage +
                                    '<td class="g-text-center">' + manualCheckingStr + '</td>' +
                                    '</tr>';
                            }

                            M('.invoice-tbody-content').html(str);
                            M(".stopEvt").on("click",function (event){
                                event.stopPropagation()
                            })
                            M.billIssueReceipt.getPage(data, page, M('#page'));
                            M('.pageTotal').html(data.total);
                            M('.pageCount').html(data.pageCount);
                            M('.billIssue-main-content tr').each(function(){
                                var timeDifference=M(this).find('.timeDifference').text();
                                if(timeDifference == ''){
                                    M(this).find('.timeDifference').siblings('i').addClass('none');
                                }
                            });
                            M(".to-checkInvoices").on("click",function(){

                                if($(this).attr('data-invoiceNum')=="null" || $(this).attr('data-invoiceNum')=="undefined"){

                                    var needinvoiceNum=''
                                }else{
                                    var needinvoiceNum=$(this).attr('data-invoiceNum')
                                }
                                if($(this).attr('data-invoiceCode')=="null"||$(this).attr('data-invoiceCode')=="undefined"){

                                    var needinvoiceCode=''
                                }else{
                                    M.billIssueReceipt.judgeCode($(this).attr('data-invoiceCode'));
                                    var needinvoiceCode=$(this).attr('data-invoiceCode')
                                }
                                if($(this).attr('data-creDate')=="null"||$(this).attr('data-creDate')=="undefined"){

                                    var needcreDate=''
                                }else{
                                    var needcreDate=M.billIssueReceipt.needDate($(this).attr('data-creDate'))
                                }
                                if($(this).attr('data-totalAmount')=="null"||$(this).attr('data-totalAmount')=="undefined"){

                                    var needtotalAmount=''
                                }else{
                                    var needtotalAmount=$(this).attr('data-totalAmount')
                                }
                                if($(this).attr('data-checkCode')=="null"||$(this).attr('data-checkCode')=="undefined"){
                                    var needcheckCode=''
                                }else{

                                    var needcheckCode=$(this).attr('data-checkCode')
                                }


                                // console.log(M.billIssueReceipt.needDate($(this).attr('data-creDate')))

                                var needId=$(this).attr('data-id')
                                var needfileAddress=encodeURI($(this).attr('data-fileAddress'))
                                // var needfileAddress='null'
                                var url = M.interfacePath.server + 'zuul/api/assets/t/assets/uploadCheckImage?ocrId=' + needId;
                                M.ui.customDialog.init({
                                    drag:true,
                                    title:'',
                                    width:'800',
                                    height:'600',
                                    autoClose:false,
                                    url:'../dialog/dialog-orcInvoice.html',
                                    callback:function(e) {
                                        var uploader = new plupload.Uploader({ //实例化一个plupload上传对象
                                            browse_button : 'addBoxdd',//上传ID
                                            headers:{
                                                'Authorization': own.fetch('userInfo').token,
                                            },
                                            url: url,
                                            runtimes: 'gears,html5,html4,silverlight,flash',
                                            flash_swf_url : '../../../../base/js/core/Moxie.swf',
                                            silverlight_xap_url : '../../../../base/js/core/Moxie.xap',
                                            multipart_params: {
                                                'Authorization': own.fetch('userInfo').token
                                            },
                                            filters: {
                                                mime_types : [ //只允许上传图片
                                                    { title : "Image files", extensions : "jpg,png" },
                                                ],
                                                max_file_size : '10485760' //最大只能上传5120kb的文件
                                            }
                                        });
                                        uploader.init(); //初始化
                                        uploader.bind('FilesAdded',function(uploader,files){
                                            var filesLens = files.length + that.contracts.length;
                                            if (that.contracts.length < 1000 && filesLens <= 1000 ) {
                                                M.ui.waiting.creat({
                                                    status:'loading',
                                                });
                                                uploader.start();
                                            } else {
                                                for (var i=0; i<files.length; i++) {
                                                    uploader.removeFile(files[i])
                                                }
                                                // M.ui.waiting.creat({
                                                //     status:false,
                                                //     time:1000,
                                                //     text:'最多只能上传五个附件',
                                                //     hide:false,
                                                // });
                                            }
                                        });
                                        uploader.bind('Error',function(uploader,errObject){
                                            // console.log(errObject);
                                            if(errObject.code == -602){
                                                M.ui.waiting.creat({
                                                    status:false,
                                                    time:1000,
                                                    text:'不能选择相同文件！',
                                                    hide:false,
                                                });
                                            }
                                            if(errObject.code == -601){
                                                M.ui.waiting.creat({
                                                    status:false,
                                                    time:1000,
                                                    text:'不支持该文件类型上传，请重新选择！',
                                                    hide:false,
                                                });
                                            }
                                            if(errObject.code == -600){
                                                M.ui.waiting.creat({
                                                    status:false,
                                                    time:1000,
                                                    text:'单个文件不能超过10M，请压缩后上传！',
                                                    hide:false,
                                                });
                                            }
                                        });
                                        uploader.bind('FileUploaded',function(uploader,files,res){
                                            var response = res.response.replace("<pre>", "").replace("</pre>", "").replace("<PRE>", "").replace("</PRE>", "").replace(/<[^>]+>/g, "")
                                            var data = JSON.parse(response);

                                            M.ui.waiting.dismiss()

                                            if( data.success ) {

                                                needfileAddress=data.data.fileAddress
                                                $('#invoiceBox').show()
                                                $('#addBoxdd').hide()
                                                $("#image").attr("src", M.interfacePath.invoicePath + "invoice/downloadFile?uploadPath="+needfileAddress);
                                                uploader.destroy()
                                            } else {
                                                M.ui.waiting.creat({
                                                    status:false,
                                                    time:3000,
                                                    text:data.message,
                                                    hide:false,
                                                    callback: function () {
                                                        if(data.code.indexOf('TK')>=0){
                                                            var codeStr=data.code;
                                                            var cod=Number(codeStr.substring(codeStr.indexOf('TK')+2));

                                                            if(cod<5){  // 登录超时
                                                                own.logout();
                                                            }
                                                            else if(cod==5){
                                                                own.logout();
                                                            }
                                                            else if(cod==6 || cod==7){  // 无权限
                                                                return window.location.href='../basic/500.html';
                                                            }
                                                        }
                                                    }
                                                });
                                            }
                                        });
                                        $('#invoiceBox').show()
                                        if(needfileAddress!="null"){
                                            $("#image").attr("src", M.interfacePath.invoicePath + "invoice/downloadFile?uploadPath="+needfileAddress);
                                            $("#bigInvoice").attr("src",M.interfacePath.invoicePath + "invoice/downloadFile?uploadPath="+needfileAddress);
                                        }else {
                                            $("#image").attr("src", "../res/images/noImg.jpg");

                                        }
                                        $('#invoiceNumber').val(needinvoiceNum)
                                        $('#totalAmount').val(needtotalAmount)
                                        $('#billingDate').val(needcreDate)
                                        $('#checkCode').val(needcheckCode)
                                        $("#invoiceCode").val(needinvoiceCode)

                                        M('.objection-btn-close').click(function () {
                                            e.remove();
                                        });
                                        ;

                                        $("#invoiceCode").blur(function(){
                                            var invoiceCode=$(this).val();
                                            var value= M.billIssueReceipt.checkCode(invoiceCode);
                                            M.billIssueReceipt.judgeCode(value);
                                        });


                                        $('#image').click(function(event){
                                            if(needfileAddress=="null"){
                                                return;
                                            }
                                            event.stopPropagation();
                                            $('.AsyncDialogBox-close').hide()
                                            var bigHeight=$(window).height()
                                            var bigWidth=$(this).width()*(bigHeight/$(this).height())
                                            var cloneImg=$(this).clone()
                                            $('#bigInvoiceBox').html(cloneImg)
                                            $('#bigInvoiceBox').show()
                                            $('#bigInvoiceBox img').css({
                                                "position": "fixed",
                                                "left": "50%",
                                                "width": bigWidth,
                                                "height": bigHeight,
                                                "margin-left":-bigWidth/2,
                                                "top": "50%",
                                                "margin-top":  -bigHeight/2,
                                                "z-index":"9999"
                                            })
                                            $('#bigInvoiceBox img').on("click",function(){
                                                $(this).hide()
                                            })
                                            $(".g-navbar-fixed").on("click",function(event){
                                                $('#bigInvoiceBox').hide()
                                            })
                                        });

                                        M("#validate-button").on("click",function(){
                                            var invoiceNumber=$('#invoiceNumber').val();
                                            var totalAmount=$('#totalAmount').val();
                                            var billingDate=$('#billingDate').val();
                                            var checkCode=$('#checkCode').val();
                                            var invoiceCode = $("#invoiceCode").val();
                                            var params={
                                                "invoiceCode":invoiceCode,
                                                "invoiceNumber":invoiceNumber,
                                                "totalAmount":totalAmount,
                                                "billingDate":billingDate,
                                                "ocrId":needId,
                                                "checkCode":checkCode

                                            }
                                            M.ajaxFn({
                                                url:M.interfacePath.assets+'t/assets/webManualPytCheck',
                                                type: 'post',
                                                data: params,
                                                dataType: 'json',
                                                success: function (data) {

                                                    if (data.success) {

                                                        M.ui.waiting.creat({
                                                            status:true,
                                                            time:1000,
                                                            text:data.message,
                                                            hide:false,
                                                            callback: function () {
                                                                e.remove();
                                                            }
                                                        });
                                                    } else {
                                                        M.ui.waiting.creat({
                                                            status:false,
                                                            time:1000,
                                                            text:data.message,
                                                            hide:false,
                                                        });
                                                    }
                                                },
                                                error: function (err) {
                                                    console.log(err)
                                                }
                                            })
                                        })

                                        M.ui.calendar.init({
                                            target: M('#billingDate'),
                                            date: {
                                                format: 'YYYY-MM-DD'
                                            },
                                            time: {
                                                enabled: false
                                            },
                                            number: 1,
                                            toggle: 1,
                                            relative: {
                                                type: 'stop'
                                            },
                                            tool: {
                                                clear: true,
                                                today: true
                                            }
                                        }, this);
                                    }
                                });
                            })

                            M(".to-details").on("click",function(){

                                var invoiceCode = $(this).attr('data-code');
                                var invoiceNumber = $(this).attr('data-number');
                                var invoicePurName = $(this).attr('data-purName');
                                var invoiceSalesNameode = $(this).attr('data-salesName');
                                var invoiceAmountTax = $(this).attr('data-amountTax');
                                var fileAddress= encodeURI($(this).attr('data-fileAddress'));

                                M.ui.customDialog.init({
                                    drag:true,
                                    title:'',
                                    width:'800',
                                    height:'600',
                                    autoClose:false,
                                    url:'../dialog/dialog-orcInvoiceDetail.html',
                                    callback:function(e) {

                                        M('.objection-btn-close').click(function () {
                                            e.remove();
                                        });

                                        $('#invoiceCode').val(invoiceCode);
                                        $('#invoiceNumber').val(invoiceNumber);
                                        $('#purchaserName').val(invoicePurName);
                                        $('#salesName').val(invoiceSalesNameode);
                                        $('#amountTax').val(invoiceAmountTax+"元");

                                        $("#image").attr("src", M.interfacePath.invoicePath + "invoice/downloadFile?uploadPath="+fileAddress);
                                        $("#bigInvoice").attr("src",M.interfacePath.invoicePath + "invoice/downloadFile?uploadPath="+fileAddress);
                                        $('#image').click(function(event){
                                            event.stopPropagation();
                                            $('.AsyncDialogBox-close').hide()
                                            var bigHeight=$(window).height()
                                            var bigWidth=$(this).width()*(bigHeight/$(this).height())
                                            var cloneImg=$(this).clone()
                                            $('#bigInvoiceBox').html(cloneImg)
                                            $('#bigInvoiceBox').show()
                                            $('#bigInvoiceBox img').css({
                                                "position": "fixed",
                                                "left": "50%",
                                                "width": bigWidth,
                                                "height": bigHeight,
                                                "margin-left":-bigWidth/2,
                                                "top": "50%",
                                                "margin-top":  -bigHeight/2,
                                                "z-index":"9999"
                                            })
                                            // $('#bigInvoiceBox img').on("click",function(){
                                            //     $(this).hide()
                                            // })
                                            $(".g-navbar-fixed").bind("click",function(event){

                                                $('#bigInvoiceBox img').hide()
                                            })
                                        });


                                    }
                                });
                            })

                        }
                    },
                    error: function (res) {
//                        console.log(res);
                    }
                    
                });
            },
            //判断是否为专票
            checkCode:function(a){//031001700211
                var c = '',b = '';
                var code = ["144031539110", "131001570151", "133011501118", "111001571071"];
                if (a.length === 12) {
                    for (var i = 0; i < code.length; i++) {
                        if (a === code[i]) {
                            c = "10";
                            break;
                        }else{
                            c = '999'
                        }
                    }
                    if(c === '999'){
                        if (a.charAt(0) == '0' && a.substring(10, 12) == '11') {
                            c = "10"
                        } else if (a.charAt(0) == '0' && (a.substring(10, 12) == '04' || a.substring(10, 12) == '05')) {
                            c = "04"
                        } else {
                            c = "99"
                        }
                    }
                } else if (a.length == 10) {
                    b = a.substring(7, 8)
                    if (b == 1 || b == 5) {
                        c = "01"
                    } else if (b == 6 || b == 3) {
                        c = "04"
                    } else{
                        c = "99"
                    }
                }else{
                    c = '99'
                }
                return c;
            },

            judgeCode:function(value){
                if (value === '10' || value === '04') {
                    //校验码显示，发票金额不显示
                    $('.tr_checkCode').show();
                    $('.tr_totalAmount').hide();

                } else if (value === '01') {
                    //发票金额显示，校验码不显示
                    $('.tr_totalAmount').show();
                    $('.tr_checkCode').hide();
                } else {
                    //发票金额显示，校验码显示
                    $('.tr_totalAmount').show();
                    $('.tr_checkCode').show();
                }
            },
            needDate:function(date){
                var y= date.substr(0,4);
                var m= date.substr(4,2);
                var d= date.substr(6,2);
             /*   var yy=y[0]
                var m=y[1].split('月')
                var mm=m[0]
                var d=m[1].split('日')
                var dd=d[0]*/
                return y + "-" + m + "-" + d;

            },
            //分页
            getPage: function (data, page, obj) {
                M.ui.page.init({
                    container: obj[0],
                    total: data.total,
                    items: M.billIssueReceipt.pageSize,
                    number: M.billIssueReceipt.pageSize,
                    entries: 2,
                    isInput: true,
                    isText: false,
                    current: page - 1,
                    callback: function (that) {
                        M.billIssueReceipt.getTableData(this.ops.current + 1)
                    }
                });
            },

        })(function () {
            M.billIssueReceipt.init();
        });
    }
)
