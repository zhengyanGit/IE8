require(['head','menu','base','tab','page'],
    function(){
        M.define('billIssue',{
            head:M.ui.head.init(),
            init:function(){
                M.ui.menu.init({
                    index:[],
                    url:M.getNormalPath('getMenu.json',4),
                    callback: function() {

                    }
                });
                this.base = M.static.init();
                this.getDate();
            },

            getDate: function(){
                var that = this;
                M.ui.tab.init({
                    index:0,
                    button:$('.g-nav-tabs-li'),
                    panel:$('.g-tab-main'),
                    event:'click',
                    currentClass:'active',
                    url:null,
                    data:null,
                    callback:function(){},
                    error:function(){}
                });

                var id = $.getUrlParam('id');
                var isSign = $.getUrlParam('isSign');
                var signNo = $.getUrlParam('signNo');
                var ismore = $.getUrlParam('ismore');


                //凭证信息
                M.ajaxFn({
                    url: $.interfacePath.bill + 't/myFinanceBillOne/query',
                    type: 'post',
                    data: {
                        billNo: id,
                    },
                    dataType: 'json',
                    success: function (res) {
//                        console.log(res)
                        if(res.success) {
                            var bill = res.data;
                            that.id = res.data.id;

                            // var user = own.fetch('userInfo');
                            var seal_box = '<div class="seal-box">\n' +
                                '                                    <div class="seal-box-time maincol">\n' +
                                '                                        <div>'+bill.unix+'</div>\n' +
                                '                                    </div>\n' +
                                '                                </div>';
                            $('#billNo').html(bill.billNo)
                            $('#billStatus').html(that.statusFormat(bill.status))
                            $('#createDate').html($.timetrans(bill.releaseDate))
                            $('#createCompany').html(bill.payerName)
                            $('#receivingCompany').html(bill.receivingName)
                            $('#createTaxNum').html(bill.taxNumPay)
                            $('#recevTaxNum').html(bill.taxNumReceiv)
                            $('#createNum').html('<span class="maincol">'+$.getFormatNumber(bill.billAmount, 2)+'</span>&nbsp;&nbsp;<span class="col60"> ( '+$.getChineseNumber(bill.billAmount)+' )</span>');
                            $('#cashDate').html($.timetrans(bill.maturityDate))
                            if (bill.acceptDate) {
                                $('#recevDate').html($.timetrans(bill.acceptDate))
                            }
                            if (bill.hashCode) {
                                $('#hashCode').html(bill.hashCode)
                            }
                            if (bill.unix) {
                                $('.hashCode_bg').prepend(seal_box);
                                $('#timeStamp').html(bill.unix)
                            }
                            $('#createMember').html(bill.operateUserName)
                            $('#passMember').html(bill.auditUserName)
                            if (bill.status == '30' || bill.status == '40' || bill.status == '45' || bill.status == '50' || bill.status =='42' ) {
                                var btn = '<button id="pdfPrint" class="ui-button ui-btn-sm ui-btn-grey">凭证打印</button>';
                                M('#print-wrap').html(btn)
                            }

                            if ( !ismore && isSign && signNo) {

                                if (signNo) {
                                    M.ajaxFn({
                                        url:  $.interfacePath.bill +'t/fianceBill/queryReceiving',
                                        type: 'post',
                                        data: {
                                            status: '00',
                                            id: that.id
                                        },
                                        dataType: 'json',
                                        success: function (res) {
//                                        console.log(res);
                                            if ( res.success ) {
                                                M.ui.waiting.creat({
                                                    status:true,
                                                    time:1000,
                                                    text:'加签成功',
                                                    hide:false,
                                                    callback: function () {
                                                        window.location.href = 'billSignin.html';
                                                    }
                                                });

                                            }else {
                                                return M.ui.waiting.creat({
                                                    status:false,
                                                    time:1000,
                                                    text:res.message,
                                                    hide:false,
                                                    callback: function () {
                                                        that.isClick = false;
                                                    }
                                                });
                                            }
                                        },
                                        error: function (err) {
                                            console.log('err+'+err)
                                        }
                                    })
                                }
                                return;
                            }else if(ismore && signNo && isSign){
                                if (signNo) {
                                    M.ajaxFn({
                                        url:  $.interfacePath.bill +'t/receivingBill/moreSynch',
                                        type: 'post',
                                        data: {
                                            status: '00',
                                            id: that.id
                                        },
                                        dataType: 'json',
                                        success: function (res) {
//                                        console.log(res);
                                            if ( res.success ) {
                                                M.ui.waiting.creat({
                                                    status:true,
                                                    time:1000,
                                                    text:'加签成功',
                                                    hide:false,
                                                    callback: function () {
                                                        window.location.href = 'billSignin.html';
                                                    }
                                                });

                                            }else {
                                                return M.ui.waiting.creat({
                                                    status:false,
                                                    time:1000,
                                                    text:res.message,
                                                    hide:false,
                                                    callback: function () {
                                                        that.isClick = false;
                                                    }
                                                });
                                            }
                                        },
                                        error: function (err) {
                                            console.log('err+'+err)
                                        }
                                    })
                                }
                                return;
                            }
                            if (signNo) {
                                if(res.data.payerIsGroup=="1"){
                                    M.ajaxFn({
                                        url:  $.interfacePath.bill +'t/auditUser/check',
                                        type: 'post',
                                        data: {
                                            status: '00',
                                            id: that.id
                                        },
                                        dataType: 'json',
                                        success: function (res) {
//                                        console.log(res);
                                            if ( res.success ) {
                                                M.ui.waiting.creat({
                                                    status:true,
                                                    time:1000,
                                                    text:'加签成功',
                                                    hide:false,
                                                    callback: function () {
                                                        window.location.href = 'billExamine.html';
                                                    }
                                                });

                                            }else {
                                                return M.ui.waiting.creat({
                                                    status:false,
                                                    time:1000,
                                                    text:res.message,
                                                    hide:false,
                                                    callback: function () {
                                                        that.isClick = false;
                                                    }
                                                });
                                            }
                                        },
                                        error: function (err) {
                                            console.log('err+'+err)
                                        }
                                    })
                                }else{

                                    M.ajaxFn({
                                        url:  $.interfacePath.bill +'t/reviewBill/more',
                                        type: 'post',
                                        data: {
                                            status: '00',
                                            id: that.id
                                        },
                                        dataType: 'json',
                                        success: function (res) {
//                                        console.log(res);
                                            if ( res.success ) {
                                                M.ui.waiting.creat({
                                                    status:true,
                                                    time:1000,
                                                    text:'加签成功',
                                                    hide:false,
                                                    callback: function () {
                                                        window.location.href = 'billExamine.html';
                                                    }
                                                });

                                            }else {
                                                return M.ui.waiting.creat({
                                                    status:false,
                                                    time:1000,
                                                    text:res.message,
                                                    hide:false,
                                                    callback: function () {
                                                        that.isClick = false;
                                                    }
                                                });
                                            }
                                        },
                                        error: function (err) {
                                            console.log('err+'+err)
                                        }
                                    })
                                }

                            }
                        }
                    },
                    error: function (err) {
                        console.log(err)
                    }
                });
                //贸易背景
                M.ajaxFn({
                    url: $.interfacePath.assets + 't/invoice/queryFileInfoByBillNo',
                    type: 'post',
                    data: {
                        billNo: id,
                    },
                    dataType: 'json',
                    success: function (res) {
//                        console.log(res)
                       if(res.success) {
                           var str = '';
                           var data = res.data;
                           var uploadStr = '';
                           for (var i=0; i<data.length; i++) {
                               var invoice = data[i];
                               var billingDate = invoice.billingDate || '';
                               if (invoice.certificateType == '1') {
                            	   var downloadTag = ''
                            	   if(invoice.fileAddress != null && invoice.fileAddress!== ''){
                            		   downloadTag = '<a class="underline" href="javascript:;" onclick="M.downloadFileXhr('+"'"+invoice.fileAddress+"'"+','+"'"+invoice.fileName+"'"+')">下载</a>';
                                   }
                                   str += '<tr>'+
                                       '<td class="g-text-center">'+ invoice.invoiceCode +'</td>'+
                                       '<td class="g-text-center">'+ invoice.invoiceNumber +'</td>'+
                                       '<td class="g-text-center">'+ billingDate +'</td>'+
                                       '<td class="g-text-center">'+ invoice.taxRate*100 +'%</td>'+
                                       '<td class="g-text-center maincol">'+ M.getFormatNumber(invoice.amountTax, 2) +'</td>'+
                                       '<td class="g-text-center maincol">'+ M.getFormatNumber(invoice.thisAmountTax, 2) +'</td>'+
                                       '<td class="g-text-center">'+invoice.purchaserName+'<br>'+
                                       invoice.salesName+
                                       '</td>'+
                                       '<td class="g-text-center">'+
                                       downloadTag +
                                       '</td>'+
                                       '</tr>'
                               }else {
                                   if(invoice.fileAddress != null && invoice.fileAddress!== ''){
                                       uploadStr += '<div class="upload-wrap g-left mar-right-20 "><i class="iconfont upload"></i><a href="javascript:;" onclick="M.downloadFileXhr('+"'"+invoice.fileAddress+"'"+','+"'"+invoice.fileName+"'"+')">'+ invoice.fileName +'</a></div>'
                                   }
                               }
                           }
                           $('.g-table-detail tbody').html(str);
                           $('#upload-con').html(uploadStr);
                           $('#remark').html(data[0].remark);

                       }
                    },
                    error: function (err) {
                        console.log(err)
                    }
                });
                //pdf Print
                M(document).on('click', '#pdfPrint', function () {
                    M.ajaxFn({
                        url:  $.interfacePath.basic +'t/autograph/filePath',
                        type: 'get',
                        data: {
                            signNo: id,
                            bizType: '19'
                        },
                        dataType: 'json',
                        success: function (res) {
//                            console.log(res);
                            if ( res.success ) {
                                M.downloadFileXhr(res.data[0].autographFilePath, '')
                            }else {
                                M.ui.waiting.creat({
                                    status:false,
                                    time:1000,
                                    text:res.message,
                                    hide:false
                                });
                            }
                        },
                        error: function (err) {
                            console.log('err+'+err)
                        }
                    });
                });

            },
            //状态格式化
            statusFormat: function (data) {
                var type = null;
                if (data == '0') {
                    type = '新增';
                } else if (data == 10) {
                    type = '待复核';
                } else if (data == '00') {
                    type = '待初审';
                } else if (data == 20) {
                    type = '待平台审核';
                } else if (data == 25) {
                    type = '待平台复核';
                } else if (data == 2) {
                    type = '复核';
                } else if (data == 28) {
                    type = '待签收';
                } else if (data == 30) {
                    type = '已开立';
                } else if (data == 40) {
                    type = '兑付中';
                } else if (data == 42) {
                    type = '兑付中';
                } else if (data == 45) {
                    type = '兑付中';
                } else if (data == 50) {
                    type = '已兑付';
                } else if (data == 90) {
                    type = '业务驳回';
                } else if (data == 95) {
                    type = '平台驳回';
                } else if (data == 96) {
                    type = '接收方驳回';
                } else if (data == 98) {
                    type = '到期作废';
                } else if(data == 99){
                    type = '已撤销';
                }
                return type;
            }



        })(function(){
            M.billIssue.init();
        });
    }
)
