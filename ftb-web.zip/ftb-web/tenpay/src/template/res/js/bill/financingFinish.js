require(['head','menu','base','tab','page', 'calendar','plupload', 'fuzzy'],
    function(){
        M.define('financingFinish',{
            head:M.ui.head.init(),
            init:function(){
                M.ui.menu.init({
                    index:[],
                    url:M.getNormalPath('getMenu.json',4),
                    callback: function() {

                    }
                });
                var urlInfo=window.location.href;
                var applicationId =  M.getUrlParam('applicationId');
                // applicationId = "FTB-RZ-20181207-JK003";
                this.applicationId = applicationId;
                $(document).on('click','.detail-btn',this.backToFinancingList);
            },

            backToFinancingList: function() {
                location.href='financingList.html';
            },

            next:function(){
                var dom = $('.js-verification');
                for(var i=0;i<dom.length;i++){
                    if($(dom[i]).val() === ''){
                        if(!$(dom[i]).hasClass('error')){
                            $(dom[i]).addClass('error').after(this.creatError($(dom[i]).attr('str')))
                        }
                        $('html, body').animate({scrollTop:($(dom[i]).offset().top)-100}, 200);
                        return;
                    }else{
                        if($(dom[i]).hasClass('error')){
                            $(dom[i]).removeClass('error');
                            $(dom[i]).next('p').remove();
                        }
                    }
                };
                this.financSure();
            }

        })(function(){
            M.financingFinish.init();
        });
    }
)
