require(['head','menu','base','tab','page','calculator'],
    function(){
        M.define('billTransferThree',{
            head:M.ui.head.init(),
            init:function(){
                M.ui.menu.init({
                    index:[],
                    url:M.getNormalPath('getMenu.json',4),
                    callback: function() {
                    }
                });
                this.base = M.static.init();
                this.getData();
                this.getTableData();
            },

            getData: function(){
                this.payment = own.fetch('stff');
                this.payment.listTransfer = [];
                var that = this;
                $('.transfer-money').html(M.getFormatNumber(that.payment.amountMoney, 2));
                $('.receiving-com').html(that.payment.receivingName);
                M('.table').on('mouseenter', '.table-tr', function (ev) {

                    if ( $(this).find('a.change-confirm').css('display') !== 'block' ) {

                        M(this).find('i.change-icon').css('display','block');
                    }
                });
                M('.table').on('mouseleave', '.table-tr', function (ev) {

                    M(this).find('i.change-icon').css('display','none');
                });
                M(document).on('keyup', '.num-ipt', function () {
                    $(this).val($(this).val().replace(/[^\d.]/g,''));
                    this.value = this.value.replace(/\.{2,}/g,"."); //只保留第一个. 清除多余的
                    this.value= this.value.replace(/\.\d{2,}$/,this.value.substr(this.value.indexOf('.'),3));
                    var value = $(this).val();
                    var array = value.split(".");
                    if((array.length >1 && array[1].length > 2) || array.length >2){
                        value = array[0] + "." +array[1].substr(0,2);
                        $(this).val(value);
                    }
                });
                M('.table').on('click', '.table-tr', function (ev) {
                    var ev = ev || window.event;
                    var target = ev.target || ev.srcElement;

                    if($(target).hasClass('change-icon')) {

                        var ipt = $(target).siblings('input');
                        ipt.css('border','1px solid #e6e6e6');
                        ipt.removeAttr("disabled");
                        ipt.val( ipt.val().replace(/,/g, '') );
                        $(target).css('display', 'none');
                        $(target).siblings('a').css('display', 'block');

                    } else if ( $(target).hasClass('change-confirm') ) {


                        var ipt = $(target).siblings('input');
                        if (parseFloat(ipt.val()).toString() !== "NaN" && parseFloat(ipt.val()) !== 0 ) {
                            ipt.val($.getFormatNumber(ipt.val(), 2)).css('border','none').attr("disabled", true);
                            $(target).css('display', 'none')
                        }else if ( parseFloat(ipt.val()) == 0 ) {
                            ipt.val($(target).parent().siblings('.have-num').text()).css('border','none').attr("disabled", true);
                            $(target).css('display', 'none')
                            M.ui.waiting.creat({
                                status:false,
                                time:1000,
                                text:'转让金额不能为零',
                                hide:false,
                            });
                        }else if (ipt.val() == '') {
                            ipt.val($(target).parent().siblings('.have-num').text()).css('border','none').attr("disabled", true);
                            $(target).css('display', 'none')
                            M.ui.waiting.creat({
                                status:false,
                                time:1000,
                                text:'转让金额不能为空',
                                hide:false,
                            });
                        }

                    } else if ( !$(target).hasClass('num-ipt') && !$(target).hasClass('change-confirm') ) {

                        if (M(this).hasClass('active')) {

                            M(this).removeClass('active');
                        } else {

                            M(this).addClass('active');
                        }
                    }
                    that.getSelectInvoice();
                });


                M('.prev-step').click(function () {
                    var stff = own.fetch('stff');
                    stff.threeStep = true;
                    own.save('stff',stff);
                });
                M('.two').click(function () {
                    var stff = own.fetch('stff');
                    stff.threeStep = true;
                    own.save('stff',stff);
                });
                M('.one').click(function () {
                    var stff = own.fetch('stff');
                    stff.twoStep = true;
                    own.save('stff',stff);
                });
                M(".next-step").click(function(){
                    that.getSelectInvoice();
                    var selectNum = parseFloat($('.select-num').text().replace(/,/g, ''));
                    var transferNum = parseFloat(own.fetch('stff').amountMoney);
                    if(selectNum == transferNum ){
                        window.location.href = 'billTransferFour.html'
                    } else if ( M('.table-tr.active').length == 0 ) {
                        M.ui.waiting.creat({
                            status:false,
                            time:1000,
                            text:'请选择通宝',
                            hide:false
                        });
                    } else{
                        M.ui.waiting.creat({
                            status:false,
                            time:1000,
                            text:'已选金额不等于转让金额',
                            hide:false
                        });
                    }
                });

            },
            getTableData:function(){
                var that = this;
                M.ajaxFn({
                    url:M.interfacePath.bill+'t/findMyBill/list',
                    type:'post',
                    dataType:'json',
                    data:{},
                    success:function(data){
//                        console.log(data)
                        var str = '';
                        var transferNum = parseFloat(own.fetch('stff').amountMoney);
                        var item = data.data;
                        if(data.success){
                            if(item != null){
                                for (var i=0;i<item.length;i++){
                                    if ( transferNum > item[i].amount ) {
                                        transferNum = M.arithmeticSub(transferNum, item[i].amount);
                                        str += '<div class="table-tr active">\n' +
                                            '      <div class="check-box"><span><i class="iconfont">&#xe74c;</i></span></div>\n' +
                                            '      <div class="bill-num">'+item[i].billHoldNo +'</div>\n' +
                                            '<div class="transferId none">'+item[i].id+'</div>'+
                                            '       <div class="create-side">'+item[i].payerName+'</div>\n' +
                                            '     <div class="transfer-num"><input class="num-ipt" disabled="disabled" type="text" maxlength="12" value="'+M.getFormatNumber(item[i].amount,2,'.',',')+'" /><i class="iconfont change-icon">&#xe6be;</i><a class="change-confirm" href="javascript:;">确定</a></div>\n' +
                                            '<div class="transferServiceFee none"></div>'+
                                            '       <div class="cash-date">'+M.timetrans(item[i].maturityDate) +'</div>\n' +
                                            '      <div class="have-num">'+M.getFormatNumber(item[i].amount,2,'.',',')+'</div>\n' +
                                            '      </div>'
                                    } else if ( transferNum > 0 && transferNum !== 0 ) {
                                        str += '<div class="table-tr active">\n' +
                                            '      <div class="check-box"><span><i class="iconfont">&#xe74c;</i></span></div>\n' +
                                            '      <div class="bill-num">' + item[i].billHoldNo + '</div>\n' +
                                            '<div class="transferId none">' + item[i].id + '</div>' +
                                            '       <div class="create-side">' + item[i].payerName + '</div>\n' +
                                            '     <div class="transfer-num"><input class="num-ipt" disabled="disabled" type="text" maxlength="12"  value="' + M.getFormatNumber(transferNum, 2, '.', ',') + '" /><i class="iconfont change-icon">&#xe6be;</i><a class="change-confirm" href="javascript:;">确定</a></div>\n' +
                                            '<div class="transferServiceFee none"></div>' +
                                            '       <div class="cash-date">' + M.timetrans(item[i].maturityDate) + '</div>\n' +
                                            '      <div class="have-num">' + M.getFormatNumber(item[i].amount, 2, '.', ',') + '</div>\n' +
                                            '      </div>';
                                        transferNum = 0;
                                    } else {
                                        str += '<div class="table-tr">\n' +
                                            '      <div class="check-box"><span><i class="iconfont">&#xe74c;</i></span></div>\n' +
                                            '      <div class="bill-num">' + item[i].billHoldNo + '</div>\n' +
                                            '<div class="transferId none">' + item[i].id + '</div>' +
                                            '       <div class="create-side">' + item[i].payerName + '</div>\n' +
                                            '     <div class="transfer-num"><input class="num-ipt" disabled="disabled" type="text" maxlength="12"  value="' + M.getFormatNumber(item[i].amount, 2, '.', ',') + '" /><i class="iconfont change-icon">&#xe6be;</i><a class="change-confirm" href="javascript:;">确定</a></div>\n' +
                                            '<div class="transferServiceFee none"></div>' +
                                            '       <div class="cash-date">' + M.timetrans(item[i].maturityDate) + '</div>\n' +
                                            '      <div class="have-num">' + M.getFormatNumber(item[i].amount, 2, '.', ',') + '</div>\n' +
                                            '      </div>';
                                    }
                                };
                                $('.table-content').append(str);
                                that.sum();
                                M('.table-tr').each(function(){
                                    M(this).find('.num-ipt').bind('input propertychange',function(){

                                        var s = parseFloat(M(this).parent().siblings('.have-num').text().replace(/,/g, ''));
                                        var num_ipt = parseInt(M(this).val(),10);
                                        if(num_ipt > s){
                                            M(this).val(s);
                                        }
                                    });
                                });
                                M('.table-content .table-tr').find('.transferServiceFee').html(0);
                                M('.table-content .table-tr:first').find('.transferServiceFee').html(own.fetch('stff').sumTransferServiceFee);
                                //  M('.table-content .table-tr:first').find('.num-ipt').val(M.amount($('.table-content .table-tr:first').find('.have-num').text()-own.fetch('stff').sumTransferServiceFee),2,'.','.');

                            }else{
                                M.ui.waiting.creat({
                                    status:false,
                                    time:1000,
                                    text:'未查找到可用的通宝单！',
                                    hide:false
                                });
                            }
                        }else{
                            M.ui.waiting.creat({
                                status:false,
                                time:1000,
                                text:data.message,
                                hide:false
                            });
                        };



                    }
                })
            },
            sum: function () {
                var totalNum = 0;
                var select = $('.table-content').find('div.active');
                for (var i=0; i<select.length; i++) {
                    totalNum = M.arithmeticAdd(totalNum, parseFloat($(select[i]).find('.num-ipt').val().replace(/,/g, '')));
                }
                $('.select-num').html($.getFormatNumber(totalNum, 2));
            },
            getSelectInvoice: function () {
                var that = this;
                that.payment.listTransfer = [];
                var select =  $('.table-content').find('div.table-tr.active');
                var sum = 0;
                for(var i=0; i<select.length; i++) {
                    sum = M.arithmeticAdd(sum, parseFloat($(select[i]).find('.num-ipt').val().replace(/,/g, '')));
                    var transferId =$(select[i]).find('.transferId').text();
                    var billNo = $(select[i]).find('.bill-num').text();
                    var payerName = $(select[i]).find('.create-side').text();
                    var maturityDate = $(select[i]).find('.cash-date').text();
                    var Amount = $(select[i]).find('.num-ipt').val().replace(/,/g, '');
                    var totalAmount = $(select[i]).find('.have-num').text().replace(/,/g, '');
                    var everyService = $(select[i]).find('.transferServiceFee').text().replace(/,/g, '');
                    that.payment.listTransfer.push({id:transferId,billNo:billNo,payerName:payerName,maturityDate:maturityDate,totalAmount:totalAmount,transferAmountStr:Amount,transferServiceFee:everyService});
                    that.payment.sum = $.getFormatNumber(sum, 2);
                    own.save('stff',that.payment)
                }
                $('.select-num').html($.getFormatNumber(sum, 2));
                var selectMoney = $.getFormatNumber(sum, 2)
            }

        })(function(){
            M.billTransferThree.init();
        });
    }
)
