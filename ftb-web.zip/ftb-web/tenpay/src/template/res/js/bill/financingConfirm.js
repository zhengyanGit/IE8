require(['head','menu','base','tab','page', 'calendar', 'confirm', 'plupload', 'fuzzy'],
    function(){
        M.define('financingConfirm',{
            head:M.ui.head.init(),
            init:function(){
                M.ui.menu.init({
                    index:[],
                    url:M.getNormalPath('getMenu.json',4),
                    callback: function() {

                    }
                });
                this.banknum = '';
                this.accountInfo = {};
                var urlInfo=window.location.href;
                var applicationId =  M.getUrlParam('applicationId');
                // applicationId = "FTB-RZ-20190327-JK013";
                this.applicationId = applicationId;
                this.getDatainfo();//初始化查询信息
                // $('.js-prev').off('click').on('click',this.prev.bind(this));
                $('.js-next').off('click').on('click',this.next.bind(this));
                $(document).on('click','.js-verification',this.removeError);
                $(document).on('keyup','.js-verification',this.check);
                $('.js-contract-add').off('click').on('click',this.contractAdd);
                $(document).on('click','.js-ui-detail',this.contractDetail);
                // this.ftbLoginInfo();
                $('.js-revoke').off('click').on('click',function () {
                    M.ui.confirm.init({
                        html:'确定撤销吗？',
                        drag: false,
                        button:[
                            {
                                href:null,
                                html:'确认',
                                callback:function(){
                                    M.financingConfirm.revoke();
                                }
                            },
                            {
                                href:null,
                                html:'关闭',
                                callback:function(){
                                    // $('body').css('height','auto');
                                }
                            }
                        ],
                        close: function () {
//                        console.log('close')
                        }
                    });
                });//撤销
                $('.info-refresh').off('click').on('click',this.infoRefresh.bind(this));//更新信息
                this.uploadInit();
                var bankNum = '';
                //限制银行名称输入数字
                // $(".js-account-name").on("keydown",function (event) {
                //     var reg=new RegExp(/[0-9]/g);
                //     if(reg.test(event.key)){
                //         return false
                //     }
                // })
                $(".js-account-name").on("keyup",function (event) {
                    var reg=new RegExp(/[0-9]/g);
                    if(reg.test(event.target.value)){
                        $(this).val("")
                    }
                })
                // $(".js-fp-bankname").on("keydown",function (event) {
                //     var reg=new RegExp(/[0-9]/g);
                //     if(reg.test(event.key)){
                //         return false
                //     }
                // })
                $(".js-fp-bankname").on("keyup",function (event) {
                    var reg=new RegExp(/[0-9]/g);
                    if(reg.test(event.target.value)){
                        $(this).val("")
                    }
                })
                M('.amount-ver').on('keyup', function () {
                    $(this).val($(this).val().replace(/[^\d]/g,''));
                });

                //模糊查询
                M('#fuzzySearch').bind('input propertychange', function () {
                    var value = M('#fuzzySearch').val();
                    if (value === '') {
                        M('#js-account-no').val('');
                    }
                });
                M.ui.fuzzy.init({
                    target:M('#fuzzySearch'),
                    url: M.interfacePath.basic + 't/yh/fuzzySearchBlank',
                    tip:false,
                    isClick:false,
                    callback:function(){
//                        console.log(this);
                        // this.targetElement.addClass('true');
                        //判断付款方收款方税号是否相同
                        var name = this.name;
                        var value = this.value;
                        M.financingConfirm.accountInfo = {
                            accountBank: name,
                            accountBankNo: value
                        }
                    }
                });

                this.getBankInfo();
                this.bankConfig = {};  //金融机构配置
            },

            getBankInfo: function() {
                $.ajaxFn({
                    url:$.interfacePath.bill+'t/nologin/getFinanceOrgConfigByAcceptCode',
                    data:{acceptCode:M.financingConfirm.applicationId},
                    type:'POST',
                    dataType:'JSON',
                    success:function(data,args){
                        if (data.success) {
                            M.financingConfirm.bankConfig = data.data;
                        } else {
                            M.ui.waiting.creat({
                                status:false,
                                time:1000,
                                text:data.message,
                                hide:false,
                            });
                        }
                    },
                    error:function(msg){
                        console.log(msg)
                    }
                })
            },

            restrictNum:function(str){


            },
            uploadInit:function(){
                var that = this;
                this.contracts = [];
                var reqData = {applicationId:this.applicationId};
                //上传图片
                var uploader = new plupload.Uploader({ //实例化一个plupload上传对象
                    browse_button : 'browse',//上传ID
                    headers:{
                        'Authorization': own.fetch('userInfo').token,
                        // 'Authorization': "eyJhbGciOiJIUzUxMiJ9.eyJqdGkiOiJkNDFmNzUxZGNmMjI0ZTZhOGEyNDNmODYzMWU3NzM5NyIsImlhdCI6MTU0NTgxMTU1Miwic3ViIjoiRjEwMDUxMDhDMSIsImRhdGEiOnsiY2FGbGFnIjoiMSIsIm9wZXJhdGVJZCI6IkYxMDA1MTA4QzEiLCJjdXN0b21lcklkIjoiRjEwMDUxMDgiLCJjYURyaXZlclR5cGUiOiIiLCJjYUFncmVlbWVudEZsYWciOiIxIiwiY3VzX2NhQWdyZWVtZW50RmxhZyI6IjEiLCJ0YXhOdW0iOiIxMjM0NTY3ODk5ODc2NTQzMjEiLCJvcGVyYXRlTmFtZSI6IuWFtOS-r-a1i-ivlSIsInVzZXJSb2xlIjpbIlIxMCIsIlIyMCJdLCJjdXN0b21lck5hbWUiOiLkuIrmtbflhbTkvq_kv6Hmga_np5HmioDmnInpmZDlhazlj7giLCJtYXJrZXRJZCI6IkJHR0MifSwiZXhwIjoxNTQ1ODEzMzUyfQ.7-u8B8yUhCfoNuhL1bOCIJhLRiz9UPBOhngym1zetHVyTg_15nucpXMAcWbktapM00vTEbvUw-iXFOUFjPCfeA"
                    },
                    url :  M.interfacePath.server + 'zuul/api/assets/t/uploadFileRz',
                    flash_swf_url : '../../../../base/js/core/Moxie.swf',
                    silverlight_xap_url : '../../../../base/js/core/Moxie.xap',
                    filters: {
                        mime_types : [ //只允许上传图片和zip文件
                            { title : "Image files", extensions : "jpg,gif,png" },
                            { title : "Zip files", extensions : "zip,rar" },
                            { title : "Document files", extensions : "doc,pdf,docx,xls,xlsx" }
                        ],
                        max_file_size : '10485760' //最大只能上传5120kb的文件
                    }
                });
                uploader.init(); //初始化

                // uploader.bind('BeforeUpload', function (uploader, files) {
                //     uploader.setOption("multipart_params",{reqData:JSON.stringify(reqData)});
                // });

                uploader.bind('BeforeUpload', function (uploader, files) { //传入表单参数
                    uploader.setOption("multipart_params", {
                        reqData:JSON.stringify(reqData)
                    });
                });

                uploader.bind('FilesAdded',function(uploader,files){
                    var filesLens = files.length + that.contracts.length;
                    if (that.contracts.length < 10 && filesLens <= 10 ) {
                        uploader.start();
                    } else {
                        for (var i=0; i<files.length; i++) {
                            uploader.removeFile(files[i])
                        }
                        M.ui.waiting.creat({
                            status:false,
                            time:1000,
                            text:'最多只能上传十个附件',
                            hide:false,
                        });
                    }
                });

                uploader.bind('Error',function(uploader,errObject){
                    // console.log(errObject);
                    if(errObject.code == -602){
                        M.ui.waiting.creat({
                            status:false,
                            time:1000,
                            text:'不能选择相同文件！',
                            hide:false,
                        });
                    }
                    if(errObject.code == -601){
                        M.ui.waiting.creat({
                            status:false,
                            time:1000,
                            text:'不支持该文件类型上传，请重新选择！',
                            hide:false,
                        });
                    }

                    if(errObject.code == -600){
                        M.ui.waiting.creat({
                            status:false,
                            time:1000,
                            text:'单个文件不能超过10M，请压缩后上传！',
                            hide:false,
                        });
                    }
                });
                uploader.bind('FileUploaded',function(uploader,files,res){
                    var response = res.response.replace("<pre>", "").replace("</pre>", "").replace("<PRE>", "").replace("</PRE>", "").replace(/<[^>]+>/g, "")
                    var data = JSON.parse(response);
                    // console.log(data);
                    if( data.success ) {
                        M.ui.waiting.creat({
                            position:'fixed',
                            status:'loading',
                            time:500,
                            callback:function(){
                                M.ui.waiting.creat({
                                    status:true,
                                    time:1000,
                                    text:data.message,
                                    hide:false,
                                });
                            }
                        });
                        that.contracts.push(data.data);
                        var file_name = files.name; //文件名
                        var file_size = data.data.size;
                        //构造html来更新UI
                        M('#uploadBox').addClass('upload-info');
                        var html2 =  '<div class="file-box">'+
                            '<div class="file-name"><a class="download" href="javascript:;">'+file_name+'</a><a href="javascript:;" class="removeItem">删除</a></div>'+
                            '<div class="file-size">'+(file_size/1024).toFixed(2)+'k</div>'+
                            '</div>'
                        $(html2).appendTo('#uploadBox');

                    } else {
                        M.ui.waiting.creat({
                            status:false,
                            time:3000,
                            text:data.message,
                            hide:false,
                            callback: function () {
                                if(data.code.indexOf('TK')>=0){
                                    var codeStr=data.code;
                                    var cod=Number(codeStr.substring(codeStr.indexOf('TK')+2));

                                    if(cod<5){  // 登录超时
                                        own.logout();
                                    }
                                    else if(cod==5){
                                        own.logout();
                                    }
                                    else if(cod==6 || cod==7){  // 无权限
                                        return window.location.href='../basic/500.html';
                                    }
                                }
                            }
                        });
                    }
                });
                // 点击下载
                $(document).on('click','.download',function(){
                    var index = $('#uploadBox .download').index($(this));
                    M.downloadFileXhr(that.contracts[index].fileAddress, that.contracts[index].fileName)
                });
                // 点击删除
                $(document).on('click','.removeItem',function(e){
                    var target = e.currentTarget;
                    var index = $('#uploadBox .removeItem').index($(target));
                    var deleteFileArr = that.contracts.splice(index, 1);
                    var deleteFile = deleteFileArr[0];
                    that.deleteFile(deleteFile);
                    $(target).parents('.file-box').remove();
                    if (that.contracts.length == 0) {
                        M('#uploadBox').removeClass('upload-info');
                    }
                }.bind(that));
            },

            deleteFile: function(file) {

                var fileId = file.fileId;
                var fileAddress = file.fileAddress;

                M.ajaxFn({
                    url:$.interfacePath.assets+'t/deleteFileRz',
                    data:{
                        fileId: fileId,
                        fileAddress: fileAddress
                    },
                    type:'POST',
                    dataType:'JSON',
                    success:function(data,args){

                    },
                    error:function(msg){
                        console.log(msg)
                    }
                })

            },

            check:function(){
                var pattern = new RegExp("[~'!@#$￥()（）%^&*()-+_=:]");
                if($(this).val().length >50 || pattern.test($(this).val())){
                    var str = $(this).val().substring(0,50)
                    $(this).val(str)
                }
            },
            revoke:function(){
                var reqData = this.applicationId;
//                console.log(reqData);
                $.ajaxFn({
                    url:$.interfacePath.bill+'t/factorselectapplyinfo/update',
                    data:{acceptCode:reqData},
                    type:'POST',
                    dataType:'JSON',
                    success:function(data,args){
                        var data = M.parseJSON(data.data);
                        if (!data) {
                            return;
                        }
                        if(data.status === '1'){
                            M.ui.waiting.creat({
                                status:true,
                                time:1000,
                                text:'撤销成功',
                                hide:false,
                                callback: function () {
                                    M.closeCurrentPage();
                                }
                            });
                        }else{
                            M.ui.waiting.creat({
                                status:true,
                                time:1000,
                                text:data.message,
                                hide:false
                            });
                        }
                    },
                    error:function(msg){
                        console.log(msg)
                    }
                })
            },
            getDatainfo:function(){
                var that = this;
                var reqData = this.applicationId;
//                console.log(reqData)
                M.ajaxFn({
                    url:$.interfacePath.bill+'t/financeapplyinfo/query',
                    data:{applicationId:reqData},
                    type:'POST',
                    dataType:'JSON',
                    success:function(data,args){
                        if($.parseJSON(data.data)){
                            data = JSON.parse(data.data)
                        }
                        if(data.result === '1'){
                            that.bankNum = data.financeApplication.bankNum;
                            if(data.financeFubiao.tradeContractName!=''){
                                $('.js-contract-list').html(that.redrenHtml((data.financeFubiao.tradeContractName).split(','),(data.financeFubiao.tradeContractNo).split(',')))
                                if((data.financeFubiao.tradeContractName).split(',').length === 1){
                                    $('.js-first-detail').hide();
                                }
                            }
                            $('.js-account-name').val(data.financeApplication.accountBank);
                            $('.js-account-bank').val(data.financeApplication.accountNo);
                            $('.js-fp-company-name').val(data.financeInvoice.fpCompanyName);
                            $('.js-fp-taxno').val(data.financeInvoice.fpTaxno);
                            $('.js-fp-address').val(data.financeInvoice.fpAddress);
                            $('.js-fp-phone').val(data.financeInvoice.fpPhone);
                            $('.js-fp-bankname').val(data.financeInvoice.fpBankname);
                            $('.js-fp-bankno').val(data.financeInvoice.fpBankno);
                            $('.js-link-man').val(data.financeApplication.warehouseLinkMan);
                            $('.js-link-addr').val(data.financeApplication.warehouseLinkAddr);
                            $('.js-link-tel').val(data.financeApplication.warehouseLinkTel);

                            M.financingConfirm.banknum = data.financeApplication.bankNum;
                            M.financingConfirm.accountInfo = {
                                accountBank: data.financeApplication.accountBank,
                                accountBankNo: data.financeApplication.accountBankNo
                            }
                        }
                    },
                    error:function(msg){
                        console.log(msg)
                    }
                })
            },
            infoRefresh: function() {
                M.ajaxFn({
                    url:$.interfacePath.basic+'n/update/capCompany',
                    type:'POST',
                    dataType:'JSON',
                    success:function(data){
                        if(data.success && data.data) {
                            data = data.data;
                            $('.js-fp-taxno').val(data.businessCreditNo);
                            $('.js-fp-address').val(data.registerAddress);
                            $('.js-fp-phone').val(data.phone);
                            if (data.pdInvoiceAcctNum){
                                $('.js-fp-bankno').val(data.pdInvoiceAcctNum);
                            }
                            if (data.pdInvoiceBank) {
                                $('.js-fp-bankname').val(data.pdInvoiceBank);
                            }
                            // $('.js-link-man').val(data.financeApplication.warehouseLinkMan);
                            // $('.js-link-addr').val(data.financeApplication.warehouseLinkAddr);
                            // $('.js-link-tel').val(data.financeApplication.warehouseLinkTel);
                        }
                    },
                    error:function(msg){
                        console.log(msg)
                    }
                })
            },
            next:function(){
                var dom = $('.js-verification');
                for(var i=0;i<dom.length;i++){
                    if($(dom[i]).val() === ''){
                        if(!$(dom[i]).hasClass('error')){
                            $(dom[i]).addClass('error').after(this.creatError($(dom[i]).attr('str')))
                        }
                        $('html, body').animate({scrollTop:($(dom[i]).offset().top)-100}, 200);
                        return;
                    }else{
                        if($(dom[i]).hasClass('error')){
                            $(dom[i]).removeClass('error');
                            $(dom[i]).next('p').remove();
                        }
                    }
                };
                this.financSure();
            },
            financSure:function(){
                var that = this;
                // var contracts = [];
                //
                // for (var i = 0; i < this.contracts.length; i++) {
                //     var item = this.contracts[i]
                //     contracts.push(item.fileId);
                // }
                //
                var childrens=$('.js-contract-list').children(),tradeContractName='',tradeContractNo='';
                // if(contracts.length<=0){
                //     if(!$('.error-tips').eq(0).hasClass('error')){
                //         $('.error-tips').eq(0).addClass('error').after('<p class="error-tips js-verification-upload">请添加附件</p>')
                //     }
                //     $('html, body').animate({scrollTop:($('.ui-confirm-annexes').eq(0).offset().top)-100}, 200);
                //     return;
                // }
                for(var j=0;j<childrens.length;j++){
                    if(j===(childrens.length-1)){
                        tradeContractName += $(childrens[j]).find('.js-contract-name').val();
                        tradeContractNo += $(childrens[j]).find('.js-contract-no').val();
                    }else{
                        tradeContractName += $(childrens[j]).find('.js-contract-name').val()+',';
                        tradeContractNo += $(childrens[j]).find('.js-contract-no').val()+',';
                    }
                }

                var reqData = {
                    applicationId:this.applicationId,
                    accountBank:$('.js-account-name').val(),
                    // accountBank: M.financingConfirm.accountInfo.accountBank,
                    // accountBankNo: M.financingConfirm.accountInfo.accountBankNo || "",
                    accountNo:$('.js-account-bank').val(),

                    fpType:$('.js-fp-type').val(),
                    fpCompanyName:$('.js-fp-company-name').val(),
                    fpTaxno:$('.js-fp-taxno').val(),
                    fpAddress:$('.js-fp-address').val(),
                    fpBankname:$('.js-fp-bankname').val(),
                    fpPhone:$('.js-fp-phone').val(),
                    fpBankno:$('.js-fp-bankno').val(),

                    linkMan:$('.js-link-man').val(),
                    linkAddr:$('.js-link-addr').val(),
                    linkTel:$('.js-link-tel').val(),
                    tradeContractName:tradeContractName,
                    tradeContractNo:tradeContractNo
                    // relationIds:contracts
                };
                M.ajaxFn({
                    url:$.interfacePath.bill+'t/factorselectapplyinfo/confirms',
                    data:reqData,
                    type:'POST',
                    dataType:'JSON',
                    success:function(data,args){
                        if (!data) {
                            return;
                        }
                        if($.parseJSON(data.data)){
                            data = JSON.parse(data.data)
                        }
                        if(data.result === '1'){

                            var url = M.financingConfirm.bankConfig.next03Page + "?applicationId=" + M.financingConfirm.applicationId;
                            location.href=url;

	                         // if (M.financingConfirm.banknum == M.interfacePath.financingOrgCode || M.financingConfirm.banknum == M.interfacePath.zhaohangCode || M.financingConfirm.banknum == M.interfacePath.gonghangCode || M.financingConfirm.banknum == M.interfacePath.jianhangCode) {
	                         //     location.href="financingFinish.html?applicationId=" + that.applicationId;
	                         // } else  {
	                        	//  if (M.isGuoCheng(that.bankNum)) {
	                         //         location.href='financingContract_GC.html?applicationId=' + that.applicationId;
	                         //     } else if(M.isHongxing(that.bankNum)) {
                              //        location.href='financingContract_HX.html?applicationId=' + that.applicationId;
                              //    } else  if(M.financingConfirm.banknum==M.interfacePath.gcleaseCode){
                              //        location.href='companyInfor.html?applicationId=' + that.applicationId;
	                         //     }else {
                              //        location.href='financingContract.html?applicationId=' + that.applicationId;
                              //    }
	                         // }
                        } else {
                            M.ui.waiting.creat({
                                status:false,
                                time:1000,
                                text:data.failReason,
                                hide:false,
                            });
                        }
                    },
                    error:function(msg){
                        console.log(msg)
                    }
                })
            },
            removeError:function(){
                if($(this).hasClass('error')){
                    $(this).removeClass('error').next('p').remove();
                }
            },
            // prev:function(){
            //     var url = "financingThree.html?applicationId=" + this.applicationId;
            //     location.href = url;
            // },
            creatError:function(str){
                return '<p class="error-tips">请填写'+str+'</p>';
            },
            redrenHtml:function(name,no){
                var str ='';
                for(var i=0;i<name.length;i++){
                    str += '<div class="col-xs-12 ui-nopadding mar-top-5">\
							<div class="col-xs-5 ui-nopadding">\
								<div class="ui-form-group ui-confirm-contract">\
									<label class="col-xs-5" >贸易合同名：<em style="color:#ea544a;margin-left: 10px;">*</em></label>\
									<div class="col-xs-7">\
										<input type="text" placeholder="贸易合同名" value="'+name[i]+'" str="贸易合同名" class="js-verification js-contract-name">\
									</div>\
								</div>\
							</div>\
							<div class="col-xs-5 ui-nopadding">\
								<div class="ui-form-group ui-confirm-contract">\
									<label class="col-xs-5" >贸易合同号：<em style="color:#ea544a;margin-left: 10px;">*</em></label>\
									<div class="col-xs-7">\
										<input type="text" placeholder="贸易合同号" value="'+no[i]+'" str="贸易合同号" class="js-verification js-contract-no">\
									</div>\
								</div>\
							</div>\
							<div class="col-xs-2 ui-nopadding js-first-detail">\
								<div class="ui-form-group">\
									<a href="JavaScript:;" class="ui-delect js-ui-detail"><span>删除</span></a>\
								</div>\
							</div>\
						</div>';
                };
                return str;
            },
            contractAdd:function(){
                $('.js-first-detail').show();
                var str = '<div class="col-xs-12 ui-nopadding mar-top-5">\
						<div class="col-xs-5 ui-nopadding">\
							<div class="ui-form-group ui-confirm-contract">\
								<label class="col-xs-5" >贸易合同名：<em style="color:#ea544a;margin-left: 10px;">*</em></label>\
								<div class="col-xs-7">\
									<input type="text" placeholder="贸易合同名" str="贸易合同名" class="js-verification js-contract-name">\
								</div>\
							</div>\
						</div>\
						<div class="col-xs-5 ui-nopadding">\
							<div class="ui-form-group ui-confirm-contract">\
								<label class="col-xs-5" >贸易合同号：<em style="color:#ea544a;margin-left: 10px;">*</em></label>\
								<div class="col-xs-7">\
									<input type="text" placeholder="贸易合同号" str="贸易合同号" class="js-verification js-contract-no">\
								</div>\
							</div>\
						</div>\
						<div class="col-xs-2 ui-nopadding js-first-detail">\
							<div class="ui-form-group">\
								<a href="JavaScript:;" class="ui-delect js-ui-detail"><span>删除</span></a>\
							</div>\
						</div>\
					</div>';
                $('.js-contract-list').append(str)
            },
            contractDetail:function(){
                var parent = $(this).parents('.js-contract-list');
                $(this).parents('.ui-nopadding').remove();
                if(parent.children().length === 1){
                    $('.js-first-detail').hide();
                }
            }

        })(function(){
            M.financingConfirm.init();
        });
    }
)
