require(['signMessage','head','menu','base','tab','page','status'],
    function(signMessage){
        M.define('contract',{
            head:M.ui.head.init(),
            init:function(){
                M.ui.menu.init({
                    index:[],
                    url:M.getNormalPath('getMenu.json',4),
                    callback: function() {

                    }
                });
                this.base = M.static.init();
                this.getDate();

            },

            getDate: function(){
                this.payment = {};
                this.submit = {};
                var that = this;
                own.removeKey('stff');

                M.ui.tab.init({
                    index:0,
                    button:$('.g-nav-tabs-li'),
                    panel:$('.g-tab-main'),
                    event:'click',
                    currentClass:'active',
                    url:null,
                    data:null,
                    callback:function(){},
                    error:function(){}
                });
                var id = M.getUrlParam('id');
                var amountMoney = $.getUrlParam('money');
                var signNo = $.getUrlParam('signNo');
                var review = $.getUrlParam('review');
                var reviewAccept = $.getUrlParam('reviewAccept');
                if (review || reviewAccept) {
                    $('.ui-page-confirm').html('<div class="col-xs-12 g-text-right">\n' +
                        '            <button class="ui-button ui-btn-lg ui-btn-green review_download" >下载</button>\n' +
                        '        </div>');
                }
                M(document).on('click', '.review_download', function () {
                    M.ajaxFn({
                        url:  $.interfacePath.basic +'t/autograph/filePath',
                        type: 'get',
                        data: {
                            signNo: that.info.financeTransferApply.batchNo,
                            bizType: '25'
                        },
                        dataType: 'json',
                        success: function (res) {
//                            console.log(res);
                            if ( res.success ) {
                                M.downloadFileXhr(res.data[0].autographFilePath, '')
                            }else {
                                M.ui.waiting.creat({
                                    status:false,
                                    time:1000,
                                    text:res.message,
                                    hide:false
                                });
                            }
                        },
                        error: function (err) {
                            console.log('err+'+err)
                        }
                    });
                });
                //pdf Print
                M.ajaxFn({
                    url:  $.interfacePath.bill +'t/transferDownLoad/pdfPrint',
                    type: 'get',
                    data: {
                        id: id
                    },
                    dataType: 'json',
                    success: function (res) {
//                        console.log(res);
                        if ( res.success ) {
                            that.ptfurl = res.data;
                        }else {
                            M.ui.waiting.creat({
                                status:false,
                                time:1000,
                                text:res.message,
                                hide:false
                            });
                        }
                    },
                    error: function (err) {
                        console.log('err+'+err)
                    }
                });
                M('#pdfPrint').click(function () {
                    M.downloadFileXhr(that.ptfurl, '')
                });

                M.ajaxFn({
                    url: $.interfacePath.bill + 't/findDebts/list',
                    type: 'post',
                    data: {
                        transferApplyId: id,
                    },
                    dataType: 'json',
                    success: function (res) {
//                        console.log(res);
                        that.info = res.data;
                        if (signNo && that.info.financeTransferApply.status !== '20') {
                            $('.ui-page-confirm').html('<div class="col-xs-12 g-text-right">\n' +
                                '            <button class="ui-button ui-btn-lg ui-btn-gray" onclick="javascript:window.close();">关闭</button>\n' +
                                '        </div>');
                            M.ajaxFn({
                                url:  $.interfacePath.bill +'/t/sginfo/originalData',
                                type: 'post',
                                data: {
                                    status: '00',
                                    id: id
                                },
                                dataType: 'json',
                                async: false,
                                success: function (res) {
                                    if ( res.success ) {
                                        M.ui.waiting.creat({
                                            status:true,
                                            time:1000,
                                            text:res.message,
                                            hide:false,
                                            callback: function () {
                                                own.removeKey('stff');
                                                if (opener) {
                                                    opener.location.reload();
                                                }
                                                window.close();
                                            }
                                        });
                                    }else {
                                        that.isClick = false;
                                        M.ui.waiting.creat({
                                            status:false,
                                            time:1000,
                                            text:res.message,
                                            hide:false
                                        });
                                    }
                                },
                                error: function (err) {
                                    console.log('err+'+err)
                                }
                            })
                        }else if (signNo && that.info.financeTransferApply.status == '20') {
                            $('.ui-page-confirm').html('<div class="col-xs-12 g-text-right">\n' +
                                '            <button class="ui-button ui-btn-lg ui-btn-gray" onclick="javascript:window.close();">关闭</button>\n' +
                                '        </div>');
                            M.ajaxFn({
                                url:  $.interfacePath.bill +'/t/sginfo/originalData',
                                type: 'post',
                                data: {
                                    status: '20',
                                    id: id
                                },
                                dataType: 'json',
                                async: false,
                                success: function (res) {
//                                    console.log(res);
                                    if ( res.success ) {
                                        M.ui.waiting.creat({
                                            status:true,
                                            time:1000,
                                            text:res.message,
                                            hide:false,
                                            callback: function () {
                                                own.removeKey('stff');
                                                opener.location.reload();
                                                window.close();
                                            }
                                        });
                                    }else {
                                        that.isClick = false;
                                        M.ui.waiting.creat({
                                            status:false,
                                            time:1000,
                                            text:res.message,
                                            hide:false
                                        });
                                    }
                                },
                                error: function (err) {
                                    console.log('err+'+err)
                                }
                            })
                        }
                        if (review || reviewAccept) {
                            M.ajaxFn({
                                url:  $.interfacePath.basic +'chapterEnterprise',
                                type: 'post',
                                data: {
                                    customerId:reviewAccept ? that.info.financeTransferApply.transferorId : that.info.financeTransferApply.transfereeId,
                                    userId: own.fetch('userInfo').userId
                                },
                                dataType: 'json',
                                success: function (res) {
//                                    console.log(res);
                                    if ( res.success ) {
                                        if (review) {
                                            if (res.data.troeePath && res.data.troeePath.length > 0) {
                                                M.downloadFileXhrImg(res.data.troeePath, '', M('#transferSign'));
                                            }
                                            if (res.data.treeIdPath && res.data.treeIdPath.length > 0) {
                                                M.downloadFileXhrImg(res.data.treeIdPath, '', M('#recevSign'));
                                            }
                                        }else {
                                            if (res.data.troeePath && res.data.troeePath.length > 0) {
                                                M.downloadFileXhrImg(res.data.troeePath, '', M('#recevSign'));
                                            }
                                            if (res.data.treeIdPath && res.data.treeIdPath.length > 0) {
                                                M.downloadFileXhrImg(res.data.treeIdPath, '', M('#transferSign'));
                                            }
                                        }


                                        M('#transferSign').show();
                                        M('#recevSign').show();
                                    }else {
                                        M.ui.waiting.creat({
                                            status:false,
                                            time:3000,
                                            text:res.message,
                                            hide:false
                                        });
                                    }
                                },
                                error: function (err) {
                                    console.log('err+'+err)
                                }
                            });
                        }
                        if(res.data.debtsBillDTOList.length ==0){
                         //   var payerName = own.fetch('userInfo').comName;
                         //   var payerEnterprisesId = own.fetch('userInfo').comId;
                            that.payment.amountMoney=res.data.financeTransferApply.transferAmount;
                            that.payment.receivingName=res.data.financeTransferApply.transfereeLegalName;
                            that.payment.transferApplyId=res.data.financeTransferApply.id;
                            that.payment.receivingEnterprisesId = res.data.financeTransferApply.transfereeId;
                            that.payment.receivingTaxNum = res.data.transfereeTaxNum;
                            var contracts = [];
                            for (var i=0; i<res.data.listDocumentsFiles.length; i++) {
                                var item = res.data.listDocumentsFiles[i];
                                var obj = {};
                                obj.fileAddress = item.fileAddress;
                                obj.format = item.fileFormat;
                                obj.fileName = item.fileName;
                                obj.size = item.fileSize;
                                contracts.push(obj)
                            }
                            that.payment.contracts = contracts;
                            that.payment.remark = res.data.financeTransferApply.businessNum;
                            own.save('stff', that.payment);
                            window.location.href = 'billTransferThree.html'

                        }else{
                            if(res.success) {
                                var bill = res.data;
                                $('#batchNo').html(bill.financeTransferApply.batchNo)
                                $('#transferSide').html(bill.financeTransferApply.transferorLegalName)
                                $('#transferCode').html(bill.transferorBusinessCreditNo)
                                $('#transTaxNum').html(bill.transferotTaxNum)
                                $('#receiveSide').html(bill.financeTransferApply.transfereeLegalName)
                                $('#receiveCode').html(bill.transfereeBusinessCreditNo)
                                $('#receiveTaxNum').html(bill.transfereeTaxNum)
                                $('#totalNum').html()
                                $('#cn_totalNum').html(M.getChineseNumber(M.getFormatNumber(bill.sumHoldAmount, 2)))
                                $('#transferNum').html(M.getFormatNumber(bill.sumAccpetAmount, 2))
                                $('#cn_transferNum').html(M.getChineseNumber(bill.sumAccpetAmount))
                                $('#paySign').html(bill.transferorSgin)
                                $('#receiveSign').html(bill.transfereeSgin)

                                if (bill.debtsBillDTOList && bill.debtsBillDTOList.length !== 0) {
                                    var str = '';
                                    for (var i=0; i<bill.debtsBillDTOList.length; i++ ) {
                                        var item = bill.debtsBillDTOList[i];
                                        var index = i+1;
                                        str += '<tr>'+

                                            '<td align="center">'+ index +'</td>'+
                                            '<td align="center">'+ item.billNo +'</td>'+
                                            '<td align="center">'+ item.payerLegalName+'</td>'+
                                            '<td align="center">'+ M.getFormatNumber(item.holdAmount) +'</td>'+
                                            '<td align="center">'+ $.getFormatNumber(item.accpetAmount, 2) +'</td>'+
                                            '<td align="center">'+ $.timetrans(item.maturityDate) +'</td>'+
                                            '</tr>'
                                    }
                                    M('#list-content').append(str);
                                }


                            }
                        }

                    },
                    error: function (err) {
                        console.log(err)
                    }
                });
                //提交
                that.isClick = false;
                that.signStatus = 0;
                M('#Confirm').click(function () {
                    if (!M('#check-confirm').attr('checked')) {
                        M.ui.waiting.creat({
                            status:false,
                            time:1000,
                            text: '请确认勾选我已阅读',
                            hide:false,
                            callback: function () {

                            }
                        });
                    }else {
                        if (!that.isClick) {

                            that.isClick = true;
                            var userInfo = own.fetch('userInfo');
                            that.submit.id = that.info.financeTransferApply.id;
                            that.submit.batchNo = that.info.financeTransferApply.batchNo;
                            that.submit.ptfurl = that.ptfurl;
                            that.status = that.info.financeTransferApply.status;
                            if (that.status !== '20') {
                                that.ajaxSubmit(that, that.ptfurl, userInfo.userId, that.submit.batchNo);
                            }else if (that.status == '20') {
                                that.ajaxSubmitAccept(that, that.ptfurl, userInfo.userId, that.submit.batchNo);
                            }
                            M.ui.waiting.creat({
                                position:'fixed',
                                status:'loading',
                                time:10000,
                                callback:function(){

                                }
                            });

                        }

                    }
                });

            },
            ajaxSubmitAccept: function(that, filePath, userId, signNo) {
                M.ajaxFn({
                    url:  $.interfacePath.basic +'uploadPdf',
                    type: 'post',
                    data: {
                        pdfFilePath: '',
                        userId: userId,
                        bizType: '25',
                        signNo: signNo,
                        bizId: signNo
                    },
                    dataType: 'json',
                    success: function (res) {
//                        console.log(res)
                        if ( res.success ) {
                            that.viewSignAccept(that, res.data);
                        }else {
                            return M.ui.waiting.creat({
                                status:false,
                                time:1000,
                                text:res.message,
                                hide:false,
                                callback: function () {
                                    that.isClick = false;
                                }
                            });
                        }
                    },
                    error: function (err) {
                        console.log('err+'+err)
                    }
                })
            },
            ajaxSubmit: function(that, filePath, userId, signNo) {
                M.ajaxFn({
                    url:  $.interfacePath.basic +'uploadPdf',
                    type: 'post',
                    data: {
                        pdfFilePath: filePath,
                        userId: userId,
                        bizType: '20',
                        signNo: signNo,
                        bizId: signNo
                    },
                    dataType: 'json',
                    success: function (res) {
//                        console.log(res)
                        if ( res.success ) {
                            that.viewSign(that, res.data);
                        }else {
                            return M.ui.waiting.creat({
                                status:false,
                                time:1000,
                                text:res.message,
                                hide:false,
                                callback: function () {
                                    that.isClick = false;
                                }
                            });
                        }
                    },
                    error: function (err) {
                        console.log('err+'+err)
                    }
                })
            },
            viewSignAccept: function (that, signNo) {
                M.ajaxFn({
                    url:  $.interfacePath.basic +'viewSign',
                    type: 'post',
                    data: {
                        signNo: signNo,
                        name: own.fetch('userInfo').userId,
                        returnUrl: 'bill/contract.html?id='+that.submit.id,
                        notifyUrl: 'bill/nologin/assigneeStearmk/asynchCallback'
                    },
                    dataType: 'json',
                    success: function (res) {
//                        console.log(res)
                        if ( res.success ) {
                            var formStr = res.data;
                            $('body').append(formStr);
                        }else {
                            return M.ui.waiting.creat({
                                status:false,
                                time:1000,
                                text:res.message,
                                hide:false,
                                callback: function () {
                                    that.isClick = false;
                                }
                            });
                        }
                    },
                    error: function (err) {
                        console.log('err+'+err)
                    }
                })
            },
            viewSign: function (that, signNo) {
                M.ajaxFn({
                    url:  $.interfacePath.basic +'viewSign',
                    type: 'post',
                    data: {
                        signNo: signNo,
                        name: own.fetch('userInfo').userId,
                        returnUrl: 'bill/contract.html?id='+that.submit.id,
                        notifyUrl: 'bill/nologin/apply/check/asynchCallback'
                    },
                    dataType: 'json',
                    success: function (res) {
//                        console.log(res)
                        if ( res.success ) {
                            var formStr = res.data;
                            $('body').append(formStr);
                        }else {
                            return M.ui.waiting.creat({
                                status:false,
                                time:1000,
                                text:res.message,
                                hide:false,
                                callback: function () {
                                    that.isClick = false;
                                }
                            });
                        }
                    },
                    error: function (err) {
                        console.log('err+'+err)
                    }
                })
            },

        })(function(){
            M.contract.init();
        });
    }
)
