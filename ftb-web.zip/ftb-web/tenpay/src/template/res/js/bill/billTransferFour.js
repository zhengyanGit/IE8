require(['head','menu','base','tab','page', 'calendar'],
    function(){
        M.define('billTransferFour',{
            head:M.ui.head.init(),
            init:function(){
                M.ui.menu.init({
                    index:[],
                    url:M.getNormalPath('getMenu.json',4),
                    callback: function() {
                    }
                });
                this.base = M.static.init();
                this.getData();
                this.getTableData();
            },
            getData: function(){
                $('.transfer-money').html($.getFormatNumber(own.fetch('stff').amountMoney, 2));
                $('.receiving-com').html(own.fetch('stff').receivingName);
                $('.select-num').html(own.fetch('stff').sum);
                M(".next-step").click(function(){
                    var newWindow = window.open();
                    M.ajaxFn({
                        url:M.interfacePath.bill+'t/financeTransferApplySubmit',
                        data:{
                            transferApplyId:own.fetch('stff').transferApplyId,
                            sumTransferAmountStr:own.fetch('stff').amountMoney,
                         //   transferServiceFee:own.fetch('stff').sumTransferServiceFee,
                            listTransferSubmitParameters:own.fetch('stff').listTransfer,
                        },
                        type:'post',
                        dataType:'json',
                        async: false,
                        success:function(res){
//                            console.log(res);
                            if(res.success){
                                var url = 'contract.html?id='+own.fetch('stff').transferApplyId;
                                newWindow.location.href = url;
                                window.location.href = 'transferBill.html';
                            }else{
                                newWindow.close();
                                M.ui.waiting.creat({
                                    status:false,
                                    time:1000,
                                    text:res.message,
                                    hide:false
                                });
                            }
                        },
                        error:function(err){
                            newWindow.close();
                            console.log(err);
                        }
                    });
                });

            },
            getTableData:function(){
                var str ='' ;
                var item = own.fetch('stff').listTransfer;
//                console.log(item);
                for(var i=0;i<item.length;i++){
                    str+= '<div class="table-tr">\n' +
                        '                                <div class="bill-num">'+item[i].billNo+'</div>\n' +
                        '                                <div class="create-side">'+item[i].payerName+'</div>\n' +
                        '                                <div class="transfer-num">'+M.getFormatNumber(item[i].transferAmountStr)+'</div>\n' +
                        '                                <div class="cash-date">'+M.timetrans(item[i].maturityDate)+'</div>\n' +
                        '                                <div class="have-num">'+M.getFormatNumber(item[i].totalAmount)+'</div>\n' +
                        '                            </div>'
                }
                $('.table-content').append(str);
            }
        })(function(){
            M.billTransferFour.init();
        });
    }
)
