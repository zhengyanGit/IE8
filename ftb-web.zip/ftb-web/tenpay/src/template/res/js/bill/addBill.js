require(['head','menu','base','tab','page', 'calendar','plupload','fuzzy','jqueryForm'],
    function(){
        M.define('addBill',{
            head:M.ui.head.init(),
            init:function(){
                M.ui.menu.init({
                    index:[],
                    url:M.getNormalPath('getMenu.json',4),
                    callback: function() {

                    }
                });

                var isQuick = M.getUrlParam('isQuick');
                this.isQuick = isQuick == "1";

                this.base = M.static.init();
                this.payment = {};
                this.payment.contracts = [];
                this.getDate();
                this.useinterface();
                // M('#browse').bind('click',function(){
                // 	M.addBill.addFile();
                // })
                M('#mark').bind('focus',function(){
                	M('.js-warning-text').hide()
                })
                M('#mark').bind('keyup', function () {
                    $(this).val($(this).val().substring(0,100));
                });
                M('#mark').bind('change', function () {
                    $(this).val($(this).val().substring(0,100));
                });
                M('#mark').bind('keydown', function () {
                    $(this).val($(this).val().substring(0,100));
                });
                M('#mark').bind('focus',function(){
                    M('.js-warning-text').hide()
                })
                M('.js-warning-text').bind('click',function(){
                	M('.js-warning-text').hide();
                	M('#mark').focus();
                })
                M('#mark').bind('blur',function(){
                	if($('#mark').val().length>0){
                		M('.js-warning-text').hide()
                	}else{
                		M('.js-warning-text').show()
                	}
                	
                })
            },
            useinterface:function(){
                var userInfo = own.fetch('userInfo');
                var signNo = $.getUrlParam('signNo');
                if (signNo){
                    M.ajaxFn({
                        url: $.interfacePath.basic + 't/more/asynchronous',
                        type: 'post',
                        dataType: 'json',
                        success: function (res) {
//                        console.log(res)
                            userInfo.cus_caAgreementFlag = '2';
                            own.save('userInfo', userInfo);
                        },
                        error: function (err) {
                            // console.log(err)
                        }
                    });
                }
            },
            addFile:function(){
            	if(M('#uploadBox').find('.Js-File-one').length==0){
            		M('#browse').attr('data-id','1')
            	}else if(M('#uploadBox').find('.Js-File-two').length==0){
            		M('#browse').attr('data-id','2')
            	}else if(M('#uploadBox').find('.Js-File-three').length==0){
            		M('#browse').attr('data-id','3')
            	}else if(M('#uploadBox').find('.Js-File-four').length==0){
            		M('#browse').attr('data-id','4')
            	}else if(M('#uploadBox').find('.Js-File-five').length==0){
            		M('#browse').attr('data-id','5')
            	}else if(!M('#browse').attr('data-id')==0){
            		M('#browse').attr('data-id','6')
            	}
            	
            	if(M('#browse').attr('data-id')==1){
            		str = '<input type="file" style="display:none" class="Js-File-one">'
                	M('#uploadBox').append(str);
                	M('.Js-File-one').click();
                	M('.Js-File-one').change(function(){
                        var file1 = $(".Js-File-one").val();
                        var pos=file1.lastIndexOf("\\");
                        var html2 =  '<div class="file-box file-box-one">'+
                        '<div class="file-name"><a class="download" href="javascript:;">'+file1.substring(pos+1)+'</a><a href="javascript:;" class="removeItem" data-id="1">删除</a></div>'+
                        // '<div class="file-size">'+1000+'k</div>'+
                        '</div>'
                        $(html2).appendTo('#uploadBox');
                        M('#browse').attr('data-id','2')
                    })
            	}else if(M('#browse').attr('data-id')==2){
            		str = '<input type="file" style="display:none" class="Js-File-two">'
                	M('#uploadBox').append(str);
                	M('.Js-File-two').click();
                	M('.Js-File-two').change(function(){
                        var file2 = $(".Js-File-two").val();
                        var pos=file2.lastIndexOf("\\");
                        var html2 =  '<div class="file-box file-box-two">'+
                        '<div class="file-name"><a class="download" href="javascript:;">'+file2.substring(pos+1)+'</a><a href="javascript:;" class="removeItem" data-id="2">删除</a></div>'+
                        // '<div class="file-size">'+1000+'k</div>'+
                        '</div>'
                        $(html2).appendTo('#uploadBox');
                        M('#browse').attr('data-id','3')
                    })
            	}else if(M('#browse').attr('data-id')==3){
            		str = '<input type="file" style="display:none" class="Js-File-three">'
                	M('#uploadBox').append(str);
                	M('.Js-File-three').click();
                	M('.Js-File-three').change(function(){
                        var file3 = $(".Js-File-three").val();
                        var pos=file3.lastIndexOf("\\");
                        var html2 =  '<div class="file-box file-box-three">'+
                        '<div class="file-name"><a class="download" href="javascript:;">'+file3.substring(pos+1)+'</a><a href="javascript:;" class="removeItem" data-id="3">删除</a></div>'+
                        // '<div class="file-size">'+1000+'k</div>'+
                        '</div>'
                        $(html2).appendTo('#uploadBox');
                        M('#browse').attr('data-id','4')
                    })
            	}else if(M('#browse').attr('data-id')==4){
            		str = '<input type="file" style="display:none" class="Js-File-four">'
                	M('#uploadBox').append(str);
                	M('.Js-File-four').click();
                	M('.Js-File-four').change(function(){
                        var file3 = $(".Js-File-four").val();
                        var pos=file3.lastIndexOf("\\");
                        var html2 =  '<div class="file-box file-box-four">'+
                        '<div class="file-name"><a class="download" href="javascript:;">'+file3.substring(pos+1)+'</a><a href="javascript:;" class="removeItem" data-id="4">删除</a></div>'+
                        // '<div class="file-size">'+1000+'k</div>'+
                        '</div>'
                        $(html2).appendTo('#uploadBox');
                        M('#browse').attr('data-id','5')
                    })
            	}else if(M('#browse').attr('data-id')==5){
            		str = '<input type="file" style="display:none" class="Js-File-five">'
                	M('#uploadBox').append(str);
                	M('.Js-File-five').click();
                	M('.Js-File-five').change(function(){
                        var file3 = $(".Js-File-five").val();
                        var pos=file3.lastIndexOf("\\");
                        var html2 =  '<div class="file-box file-box-five">'+
                        '<div class="file-name"><a class="download" href="javascript:;">'+file3.substring(pos+1)+'</a><a href="javascript:;" class="removeItem" data-id="5">删除</a></div>'+
                        // '<div class="file-size">'+1000+'k</div>'+
                        '</div>'
                        $(html2).appendTo('#uploadBox');
                        M('#browse').attr('data-id','6')
                    })
            	}else{
            		 M.ui.waiting.creat({
	        			 status:false,
	        			 time:1000,
	        			 text:'最多只能上传五个附件',
	        			 hide:false,
            		 });
            	}

            	
            },
            getDate: function(){
                var signNo = $.getUrlParam('signNo');
                var isQuick = $.getUrlParam('isQuick');
                if (own.fetch('userInfo').cus_caAgreementFlag != '2' && (!signNo || signNo.length == 0)) {
                    if(isQuick=='1'){
                        return window.location.href="billContract.html?isQuick=1";
                    }else{
                        return window.location.href="billContract.html?";
                    }

                }
                var that = this;
                //付款方信息取本地数据
                if (localStorage.userInfo) {
                    var payCompany = own.fetch('userInfo').comName;
                    $('.payer-info .company-name').html(payCompany);
                    var taxNum = own.fetch('userInfo').taxNum;
                    var businessCreditNo = own.fetch('userInfo').businessCreditNo;
                    that.payment.payerTaxNum = taxNum;
                    if (businessCreditNo) {
                        $('.payer-info .tax-num').html(own.fetch('userInfo').businessCreditNo);
                    }else {
                        $('.payer-info .tax-num').html(taxNum);
                    }
                }
                //获取可用额度
                M.ajaxFn({
                    url:  $.interfacePath.basic +'t/usCredit/selectCreditByMemberId',
                    type: 'post',
                    data: {
                        memberId: own.fetch('userInfo').comId,
                    },
                    dataType: 'json',
                    success: function (res) {
                        // console.log(res);
                        if ( res.success ) {
                            if (res.data.remainingAmount != null && res.data.creditRemain > res.data.remainingAmount) {
                                M('#useNo').html(M.getFormatNumber(res.data.remainingAmount, 2));
                                M('#isMonth').html('(当月)');
                            } else {
                                M('#useNo').html(M.getFormatNumber(res.data.creditRemain, 2));
                                M('#isMonth').html('');
                            }
                            if (res.data.singleQuota || res.data.singleQuota > 0) {
                                M('#singleLimit').show();
                                M('#singleLimitNo').html(M.getFormatNumber(res.data.singleQuota, 2));;
                            } else {
                                M('#singleLimit').hide();
                                M('#singleLimitNo').html(0);;
                            }

                            if (res.data.paymentTermDate && res.data.paymentTermDate.length > 0) {
                                M.addBill.calender.ops.date.max = res.data.paymentTermDate;
                            }

                        }else if(res.data === null) {
                            M('#useNo').html('0');
                        } else {
                            M.ui.waiting.creat({
                                status:false,
                                time:1000,
                                text:res.message,
                                hide:false,
                            });
                        }
                    },
                    error: function (err) {
                        console.log('err+'+err)
                    }
                });
                //根据本地localStorage判断用户是否填写第一步信息
                if ( own.fetch('bill').contracts && own.fetch('bill').saveFlag ) {
                    var bill = own.fetch('bill');
                    bill.saveFlag = false;
                    own.save('bill', bill);
                    M('#amountNo').val(bill.amountMoney);
                    M('.upper-cn').html(M.getChineseNumber(M('#amountNo').val()));
                    M('#js-calender').val(bill.expirationTimeStr);
                    M('#fuzzySearch').val(bill.receivingName);
                    $('.receiving-info .tax-num').html(bill.receivingTaxNum);
                    M('#mark').val(bill.remark);
                    if(bill.remark!==''){
                        M('.js-warning-text').hide()
                    }
                    that.payment.receivingName = bill.receivingName;
                    that.payment.receivingEnterprisesId = bill.receivingEnterprisesId;
                    that.payment.receivingTaxNum = bill.receivingTaxNum;
                    that.payment.legalRepresentativeOffice = bill.legalRepresentativeOffice;
                    that.payment.contracts = bill.contracts;
                    for(var i=0; i< bill.contracts.length; i++){
                        var file = bill.contracts[i];
                        var file_name = file.fileName; //文件名
                        var file_size = file.size;
                        //构造html来更新UI
                        // M('#uploadBox').addClass('upload-info');
                        var html2 =  '<div class="file-box">'+
                            '<div class="file-name"><a class="download" href="javascript:;">'+file_name+'</a><a href="javascript:;" class="removeItem">删除</a></div>'+
                            '<div class="file-size">'+(file_size/1024).toFixed(2)+'k</div>'+
                            '</div>'
                        $(html2).appendTo('#uploadBox');
                    }
                }else {
                    own.removeKey('bill');
                }
                M.ui.tab.init({
                    index:0,
                    button:$('.g-nav-tabs-li'),
                    panel:$('.g-tab-main'),
                    event:'click',
                    currentClass:'active',
                    url:null,
                    data:null,
                    callback:function(){},
                    error:function(){}
                });
                M.ui.page.init({
                    container:M('#page')[0],
                    total:50,
                    items:10,
                    number:4,
                    entries:1,
                    isInput:true,
                    isText:false,
                    current:0,
                    callback:function(that){}
                });
                var calender = M.ui.calendar.init({
                    target:M('#js-calender'),
                    date:{
                        format:'YYYY-MM-DD',
                    },
                    time:{
                        enabled:false,
                    },
                    number:1,
                    tool:{
                        clear:false,
                        today:false
                    },
                    callback:function(){
                        this.ops.date.min = M.currentDate();
                    },
                    choose:function(e){
                        var select = this.ops.date.select;
                        M.ajaxFn({
                            url:  $.interfacePath.bill +'t/currntTime/workDay',
                            type: 'post',
                            data: {
                                date: select,
                                releaseDate: M.currentDate()
                            },
                            dataType: 'json',
                            success: function (res) {
//                                console.log(res);
                                if ( res.success ) {

                                }else {
                                    M('#js-calender').val('');
                                    M.ui.waiting.creat({
                                        status:false,
                                        time:1000,
                                        text:res.message,
                                        hide:false,
                                    });
                                }
                            },
                            error: function (err) {
                                console.log('err+'+err)
                            }
                        });
                    }
                });
                this.calender = calender;
                M('.notice-icon').hover(function () {
                    $(this).siblings('div.tips').addClass('show');
                },function () {
                    $(this).siblings('div.tips').removeClass('show');
                });
                M('#amountNo').on('keyup', function () {
                    $(this).val($(this).val().replace(/[^\d.]/g,''));
                    this.value = this.value.replace(/^0+/g,'');
                    this.value = this.value.replace(/\.{2,}/g,"."); //只保留第一个. 清除多余的
                    var value = $(this).val();
                    if (value.charAt(0) == '.') {
                        value = $(this).val().substr(1);
                        $(this).val(value);
                    }
                    var array = value.split(".");
                    if((array.length >1 && array[1].length > 2) || array.length >2){
                        value = array[0] + "." +array[1].substr(0,2);
                        $(this).val(value);
                    }
                    var useNo = parseFloat(M('#useNo').text().replace(/,/g, ''));
                    var singleLimitNo = parseFloat(M('#singleLimitNo').text().replace(/,/g, ''));
                    if (singleLimitNo != 0) {
                        if (parseFloat(M('#amountNo').val()) > singleLimitNo) {
                            if (singleLimitNo < useNo) {
                                M('#amountNo').val(M('#singleLimitNo').text().replace(/,/g, ''));
                                M.ui.waiting.creat({
                                    status:false,
                                    time:1000,
                                    text:'开立金额不能大于单张限额',
                                    hide:false,
                                });
                            }
                        }
                    }

                    if (useNo === 0) {
                        M('#amountNo').val(M('#useNo').text().replace(/,/g, ''));
                        M.ui.waiting.creat({
                            status:false,
                            time:1000,
                            text:'可用余额为0，不能开立',
                            hide:false,
                        });
                    }else if (parseFloat(M('#amountNo').val()) > useNo) {
                        M('#amountNo').val(M('#useNo').text().replace(/,/g, ''));
                        M.ui.waiting.creat({
                            status:false,
                            time:1000,
                            text:'开立金额不能大于可用余额',
                            hide:false,
                        });
                    }
                    M('.upper-cn').html($.getChineseNumber(M('#amountNo').val()));
                });


                M('#fuzzySearch').bind('input propertychange', function () {

                    var value = M('#fuzzySearch').val();
                    if (value === '') {
                        $('.receiving-info .tax-num').html('');
                    }

                });
                M.ui.fuzzy.init({
                    target:M('#fuzzySearch'),
                    url: M.interfacePath.basic + 'n/user/requestCompanyInfoByBlur',
                    param: {
                        "chineseFullName": "",
                    },
                    tip:false,
                    isClick:false,
                    callback:function(){
//                        console.log(this);
                        // this.targetElement.addClass('true');
                        //判断付款方收款方税号是否相同
                        if (that.payment.payerTaxNum !== this.taxNum) {
                            that.payment.receivingName = this.name;
                            that.payment.receivingEnterprisesId = this.value;
                            that.payment.receivingTaxNum = this.taxNum;
                            that.payment.legalRepresentativeOffice = this.legalRepresentativeOffice;
                            $('.receiving-info .tax-num').html(this.taxNum);
                        }else {
                            M('#fuzzySearch').val('');
                            $('.receiving-info .tax-num').html('');
                            M.ui.waiting.creat({
                                status:false,
                                time:1000,
                                text:'开立方和接收方不能是同一个企业',
                                hide:false,
                            });
                        }
                        // $('.g-input-select-dropdown').remove();

                    }
                });

                // 上传图片
               var uploader = new plupload.Uploader({ //实例化一个plupload上传对象
                   browse_button : 'browse',//上传ID
                   headers:{
                       'Authorization': own.fetch('userInfo').token,
                   },
                   url :  M.interfacePath.assetsUpload,
                   runtimes: 'gears,html5,html4,silverlight,flash',
                   flash_swf_url : '../../../../base/js/core/Moxie.swf',
                   silverlight_xap_url : '../../../../base/js/core/Moxie.xap',
                   multipart_params: {
                       'Authorization': own.fetch('userInfo').token
                   },
                   filters: {
                       mime_types : [ //只允许上传图片和zip文件
                           { title : "Image files", extensions : "jpg,gif,png" },
                           { title : "Zip files", extensions : "zip,rar" },
                           { title : "Document files", extensions : "doc,pdf,docx,xls,xlsx" }
                       ],
                       max_file_size : '10485760' //最大只能上传5120kb的文件
                   }
               });
               uploader.init(); //初始化

               uploader.bind('FilesAdded',function(uploader,files){
                   var filesLens = files.length + that.payment.contracts.length;
                   if (that.payment.contracts.length < 5 && filesLens <= 5 ) {
                       uploader.start();
                   } else {
                       for (var i=0; i<files.length; i++) {
                           uploader.removeFile(files[i])
                       }
                       M.ui.waiting.creat({
                           status:false,
                           time:1000,
                           text:'最多只能上传五个附件',
                           hide:false,
                       });
                   }
               });

               uploader.bind('Error',function(uploader,errObject){
                   // console.log(errObject);
                   if(errObject.code == -602){
                       M.ui.waiting.creat({
                           status:false,
                           time:1000,
                           text:'不能选择相同文件！',
                           hide:false,
                       });
                   }
                 if(errObject.code == -601){
                  M.ui.waiting.creat({
                     status:false,
                     time:1000,
                     text:'不支持该文件类型上传，请重新选择！',
                      hide:false,
                      });
                 }

                 if(errObject.code == -600){
                  M.ui.waiting.creat({
                     status:false,
                     time:1000,
                     text:'单个文件不能超过10M，请压缩后上传！',
                     hide:false,
                      });
                 }
               });
               uploader.bind('FileUploaded',function(uploader,files,res){
                   var response = res.response.replace("<pre>", "").replace("</pre>", "").replace("<PRE>", "").replace("</PRE>", "").replace(/<[^>]+>/g, "")
                   var data = JSON.parse(response);
                   // console.log(data);
                   if( data.success ) {
                       M.ui.waiting.creat({
                           position:'fixed',
                           status:'loading',
                           time:500,
                           callback:function(){
                               M.ui.waiting.creat({
                                   status:true,
                                   time:1000,
                                   text:data.message,
                                   hide:false,
                               });
                           }
                       });
                       that.payment.contracts.push(data.data);
                       var file_name = files.name; //文件名
                       var file_size = data.data.size;
                       //构造html来更新UI
                       // M('#uploadBox').addClass('upload-info');
                       var html2 =  '<div class="file-box">'+
                           '<div class="file-name"><a class="download" href="javascript:;">'+file_name+'</a><a href="javascript:;" class="removeItem">删除</a></div>'+
                           '<div class="file-size">'+(file_size/1024).toFixed(2)+'k</div>'+
                           '</div>'
                       $(html2).appendTo('#uploadBox');

                   } else {
                       M.ui.waiting.creat({
                           status:false,
                           time:3000,
                           text:data.message,
                           hide:false,
                           callback: function () {
                               if(data.code.indexOf('TK')>=0){
                                   var codeStr=data.code;
                                   var cod=Number(codeStr.substring(codeStr.indexOf('TK')+2));

                                   if(cod<5){  // 登录超时
                                       own.logout();
//                                    	localStorage.removeItem("userInfo");
//                                    	window.location.href=M.interfacePath.server+"/ftb-web/template/basic/login.html";
//                                         return window.location.href = M.interfacePath.singleLogin;
                                   }
                                   else if(cod==5){
                                       own.logout();
//                                      window.location.href=M.interfacePath.server+"/ftb-web/template/basic/login.html";
//                                      return window.location.href = M.interfacePath.singleLogin;
                                   }
                                   else if(cod==6 || cod==7){  // 无权限
                                       return window.location.href='../basic/500.html';
                                   }
                               }
                           }
                       });
                   }
               });
                // 点击下载
                $(document).on('click','.download',function(){
                    var index = $('#uploadBox .download').index($(this));
                    M.downloadFileXhr(that.payment.contracts[index].fileAddress, that.payment.contracts[index].fileName)
                });
                // 点击删除
                $(document).on('click','.removeItem',function(){
                    var index = $('#uploadBox .removeItem').index($(this));
                    that.payment.contracts.splice(index, 1);
                    $(this).parents('.file-box').remove();
                    // if (that.payment.contracts.length == 0) {
                    //     M('#uploadBox').removeClass('upload-info');
                    // }
                });

                M('#amountNo').bind('input propertychange',function(){
                    var num_ipt = parseInt(M(this).val(),10);
                    if(num_ipt < 0){
                        M(this).val(0);
                    }
                });
                $('#nextStep').click(function () {
                    var payerName = own.fetch('userInfo').comName;
                    var payerEnterprisesId = own.fetch('userInfo').comId;
                    var receivingName = $('#fuzzySearch').val();
                    var receivingTaxNum = $('.receiving-info .tax-num').html();
                    var amountMoney = $('#amountNo').val();
                    var expirationTimeStr = $('#js-calender').val();
                    var remark = $('#mark').val();
                    if ( amountMoney== '') {
                        M.ui.waiting.creat({
                            status:false,
                            time:1000,
                            text:'开立金额不能为空',
                            hide:false,
                        });
                        M('#amountNo').focus();
                    }else if(amountMoney== 0){
                        M.ui.waiting.creat({
                            status:false,
                            time:1000,
                            text:'开立金额不能为0',
                            hide:false,
                        });
                        M('#amountNo').focus();
                    }else if (expirationTimeStr == '') {
                        M.ui.waiting.creat({
                            status:false,
                            time:1000,
                            text:'兑付日期不能为空',
                            hide:false,
                        });
                        M('#js-calender').focus();
                    }else if (receivingName == '') {
                        M.ui.waiting.creat({
                            status:false,
                            time:1000,
                            text:'收款方公司名称不能为空',
                            hide:false,
                        });
                        M('#fuzzySearch').focus();
                    }else if (receivingTaxNum == '') {
                        M.ui.waiting.creat({
                            status:false,
                            time:1000,
                            text:'收款方税号不能为空',
                            hide:false,
                        });
                    }else if (remark == '') {
                        M.ui.waiting.creat({
                            status:false,
                            time:1000,
                            text:'业务背景信息不能为空',
                            hide:false,
                        });
                        M('#mark').focus();
                    }else if (that.payment.contracts.length == 0) {
                        M.ui.waiting.creat({
                            status:false,
                            time:1000,
                            text:'附件不能为空',
                            hide:false,
                        });
                        setTimeout(function () {
                            M('#browse').click();
                        },500)
                    }else {
                        that.payment.payerName = payerName;
                        that.payment.payerEnterprisesId = payerEnterprisesId;
                        that.payment.amountMoney = amountMoney.replace(/[^\d.]/g,'');
                        that.payment.expirationTimeStr = expirationTimeStr;
                        that.payment.remark = remark;
                        that.payment.invoiceInfos = own.fetch('bill').invoiceInfos || [];
                        that.payment.isQuick = M.addBill.isQuick;
                        // console.log(that.payment)
                        own.save('bill', that.payment);

                        if (M.addBill.isQuick) {
                            window.location.href = 'billConfirm.html'
                        } else {
                            window.location.href = 'addBillTwo.html'
                        }
                    }

                })



            },



        })(function(){
            M.addBill.init();
        });
    }
)
