require(['head','menu','base','tab','page'],
    function(){
        M.define('noticeTransferDetail',{
            head:M.ui.head.init(),
            init:function(){
                M.ui.menu.init({
                    index:[],
                    url:M.getNormalPath('getMenu.json',4),
                    callback: function() {

                    }
                });
                this.base = M.static.init();
                this.noticeId = M.getUrlParam('noticeId');
                this.getDate();
                this.getTableData();
            },

            getDate: function(){

                M('.noticeDetailDownload').click(function(event) {
                    M.ajaxFn({
                        url: M.interfacePath.bill + 't/financeTransferNotice/pdfPrint',
                        type: 'GET',
                        data: {
                            "id": M.noticeTransferDetail.noticeId,
                        },
                        dataType: 'json',
                        contentType: 'application/json',
                        success: function (data) {
                            if(data.success && data.data != null){
                                M.downloadFileXhr(data.data,null);
                            }
                        },
                        error: function (res) {
                            console.log(res);
                        }
                    });
                });

            },

            getTableData: function (page) {

                var id = M.noticeTransferDetail.noticeId;

                M.ajaxFn({
                    url: M.interfacePath.bill + 't/financeTransferNotice/select',
                    type: 'post',
                    data: {
                        "id": id,
                    },
                    dataType: 'json',
                    contentType: 'application/json',
                    success: function (data) {

                        var res = data.data;

                        if (!res) {
                            return;
                        }

                        var billid = res.billId || "";

                        var str  =  '<tr>' +
                                        '<td width="10%" align="center">序号</td>' +
                                        '<td width="15%" align="center">通宝编号</td>' +
                                        '<td width="20%" align="center">标的债权金额</td>' +
                                        '<td width="20%" align="center">兑付日期</td>' +
                                    '</tr>';

                        str += '<tr>' +
                            '<td align="center">' + "1" + '</td>' +
                            '<td align="center">' + res.billNo + '</td>' +
                            '<td align="center">' + M.getFormatNumber(res.amount,2,'.',',') + '</td>' +
                            '<td align="center">' + M.timetrans(res.maturityDate) + '</td>' +
                            '</tr>';


                        var date = new Date(res.createDate);
                        var YY = date.getFullYear();
                        var MM = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1);
                        var DD = (date.getDate() < 10 ? '0' + (date.getDate()) : date.getDate());


                        var stringE=res.bizNo;
                        var se=stringE.substr(0,1);
                        if(se == "Z"){
                            $(".noticeTxt").html("《应收账款债权转让协议》");
                        }else if(se == "R"){
                            $(".noticeTxt").html("保理业务合同");
                        }
                        M('.g-tbody').html(str);
                        M('.creater').html(res.payerLegalName);
                        M('.accepter').html(res.transfereeLegalName);
                        M('.year').html(YY);
                        M('.month').html(MM);
                        M('.day').html(DD);
                        M('.amount').html(M.getFormatNumber(res.amount,2,'.',','));
                        M('.amountCap').html(M.getChineseNumber(res.amount));
                        M('.outer').html(res.transferorLegalName);
                        M('.notice-date').html(M.timetrans_cn(res.createDate));
                    },
                    error: function (res) {
                        console.log(res);
                    }
                });
            },

        })(function(){
            M.noticeTransferDetail.init();
        });
    }
)
