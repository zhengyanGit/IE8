require(['base','menu','status'],
    function(){
        M.define('login',{

            init:function(){
            	
                this.base = M.static.init();
                this.getData();
               // this.login();
                $("#D-login").attr("action",$.interfacePath.remoteLogin);
                $("#remoteLoginPage").val(encodeURIComponent($.interfacePath.loginUrl));
                $("#captcha").attr('src',$.interfacePath.verificationUrl + new Date().getTime() );
                $("#capRegUrl").attr('href',$.interfacePath.capRegUrl);
                $(".capRegUrl").attr('href',$.interfacePath.capRegUrl);
                $("#forgetPwd").attr('href',$.interfacePath.forgetPwd);

            },

            getData: function(){
//                localStorage.clear();
                //页面错误信息
                var userError = "error.authentication.credentials.bad.usernameorpassword.username";
                var userPwdError = "error.authentication.credentials.bad.usernameorpassword.password";
                var userImgError = "error.authentication.validatecode.bad";
                var logError = "error.authentication.duplicatelogin.bad";
                var lockeduser = "error.authentication.credentials.bad.lockeduser";
                var errMsg = M.getUrlParam("error");
                if(errMsg == userError){
                    M.ui.status.init({
                        html:'用户名不存在'
                    });
                }else if(errMsg == userPwdError){
                    M.ui.status.init({
                        html:'密码错误'
                    });
                }else if(errMsg ==userImgError ){
                    M.ui.status.init({
                        html:'验证码错误'
                    });
                }else if(errMsg == logError){
                    M.ui.status.init({
                        html:'重复登录'
                    });
                }else if(errMsg == lockeduser){
                    M.ui.status.init({
                        html:'您的账号已锁定，请24小时后再尝试登录，或咨询4008201688.'
                    });
                }
                
//                debugger;
            	if(M.cookie.read("login")){
	                if (localStorage.userInfo) {
	                    var userInfo = own.fetch('userInfo');
                        var userRole = userInfo.userRole;
                        if(!userRole || userRole.length == 0){
                            own.logout();
                            return;
                        }

                        if(userRole[0] == "R55"){
                            return window.location.href= M.interfacePath.server+ "privilege/index.html#/platform/user-platform";
                        }
                        if(userRole[0] == "R10"){
                            window.location.href="../basic/workbench.html";
                        }else{
                            window.location.href="../basic/workbench-supplier.html";
                        }
	                }else{
	                	own.logout();
	                }
            	}else{
            		if ( localStorage.userInfo) {
//            			own.logout();
            			localStorage.clear()
	                }
            	}
                $(function() {
                    $(".btn_union").click(function(){
                        var tempUsername = $("#uname").val();
                        var tempPassword = $("#upassdword").val();
                        var verification = $('#verification').val()
                        if(tempUsername==''){
                            $("#errorUsernameMsg").show();
                            $("#errorUsernameMsg").html("用户名不能为空");
                            return;
                        }else{
                            $("#errorUsernameMsg").hide();
                        };
                        if(tempPassword==''){
                            $("#errorPasswordMsg").show();
                            $("#errorPasswordMsg").html("密码不能为空");
                            return
                        }else{
                            $("#errorPasswordMsg").hide();
                        };
                        if(verification ==''){
                            $('#errorVerMsg').show();
                            $('#errorVerMsg').html('请输入验证码');
                            return;
                        }else{
                            $("#errorVerMsg").hide();
                        };
                        if(tempUsername!=''&&tempPassword!=''&&verification !=''){
                          //  onclick="javascript:document.forms[0].submit();"
                            $('form:first').submit();
                        }
                    });
                    $("#uname").blur(function(){
                        var tempUsername = $("#uname").val();
                        if(tempUsername==''){
                            $("#errorUsernameMsg").show();
                            $("#errorUsernameMsg").html("用户名不能为空");
                            return;
                        }else{
                            $("#errorUsernameMsg").hide();
                        };
                    });
                    $("#upassdword").blur(function(){
                        var tempPassword = $("#upassdword").val();
                        if(tempPassword==''){
                            $("#errorPasswordMsg").show();
                            $("#errorPasswordMsg").html("密码不能为空");
                            return
                        }else{
                            $("#errorPasswordMsg").hide();
                        };
                    });
                    $(document).keyup(function(event){
                        if(event.keyCode ==13){
                            $(".btn_union").trigger("click");
                        }
                    });
                    $(".unite_login label").click(function(){
                        var index=$(this).index();
                        $(this).addClass("current").siblings().removeClass("current");
                        $(this).closest(".login_frame").find(".infor").eq(index).show().siblings(".infor").hide();
                    });
                });

                $("#welcome").keyup(function(e){
                    if(e.keyCode==9){
                        $("#validateCode").focus();
                    }
                });

                $('div#span_ccode>a').click(function () {
                    $(this).find('img').attr('src', M.interfacePath.verificationUrl + new Date().getTime() );
                });
                $(function(){
                    $('.union_code>a').click(function(){
                        $('.union_code').find('img').attr('src',M.interfacePath.verificationUrl+new Date().getTime());
                    });
                });
            },
            // login:function(){
            //     M(function(){
            //         url:'http://10.60.36.160:8008/api/basic/n/user/login',
            //         M("#btn_login").click(function(){
            //              var data = $("#fm3").serializeObject();
            //             M.ajaxFn({
            //                 url:'http://uatcas.ouyeelf.com/cas/remoteLogin?service=http%3A%2F%2F10.60.36.160:8008%2Frf-basic%2Fn%2Fuser%2FloginApi%3Fsyscode%3DRF%26originalTargetUri%3D%252Fmain%252FhomePageLogin.do',
            //                 data:data,
            //                 type:'post',
            //                 dataType:'json',
            //                 success:function(data){
            //                     console.log(data);
            //                     if (data.success) {   // 登入成功
            //                         // 设置 token 数据
            //                         var userInfo = {};
            //                         userInfo["login"] = true;
            //                         userInfo["userName"] = data.data.user.operateName;
            //                         userInfo["userId"] = data.data.user.operateId;
            //                         userInfo["comId"] = data.data.user.customerId;
            //                         userInfo["comName"] = data.data.user.customerName;
            //                         userInfo["token"] = data.data.token;
            //                         userInfo["userRole"] = data.data.user.userRole;
            //                         var userRole = userInfo.userRole;
            //                         //存token
            //                         own.save('userInfo', userInfo);
            //                         if(userRole == "00"){
            //                             window.location.href="../assets/paymentForMe.html";
            //                         }else if(userRole == "R10"){
            //                             window.location.href="../assets/enterpriseWorkbench.html";
            //                         }else if(userRole == "R20"){
            //                             window.location.href="../assets/supplierWorkbench.html";
            //                         }else{
            //                             window.location.href="../assets/paymentForMe.html";
            //                         }
            //                     }
            //                 },
            //                 error:function(err){
            //                     console.log(err);
            //                 }
            //             });
            //         });
            //     });
            // },
        })(function(){
            M.login.init();
        });
    }
)
