require(['head', 'menu', 'base', 'tab', 'page', 'status'],
    function () {
        M.define('platformContracts', {
            head: M.ui.head.init(),
            init: function () {
                M.ui.menu.init({
                    index: [6, 0],
                    url: M.getNormalPath('getMenu.json', 4),
                    callback: function () {

                    }
                });
                this.base = M.static.init();
                this.getDate();
            },

            getDate: function () {
                var that = this;
                //pdf Print
                M(document).on('click', '.download', function () {
                    M.ajaxFn({
                        url:  $.interfacePath.basic +'t/platformRules/pdfPrint',
                        type: 'get',
                        data: {
                            bizType: M(this).attr('data-type')
                        },
                        dataType: 'json',
                        success: function (res) {
                           // console.log(res);
                            if ( res.success ) {
                                M.downloadFileXhr(res.data, '')
                            }else {
                                M.ui.waiting.creat({
                                    status:false,
                                    time:1000,
                                    text:res.message,
                                    hide:false
                                });
                            }
                        },
                        error: function (err) {
                            console.log('err+'+err)
                        }
                    });
                });
                M(document).on('click', '.downloadSign', function () {
                    M.ajaxFn({
                        url:  $.interfacePath.basic +'t/autograph/filePath',
                        type: 'get',
                        data: {
                            signNo: '',
                            bizType: M(this).attr('data-type')
                        },
                        dataType: 'json',
                        success: function (res) {
//                            console.log(res);
                            if ( res.success ) {
                                M.downloadFileXhr(res.data[0].autographFilePath, '')
                            }else {
                                M.ui.waiting.creat({
                                    status:false,
                                    time:1000,
                                    text:res.message,
                                    hide:false
                                });
                            }
                        },
                        error: function (err) {
                            console.log('err+'+err)
                        }
                    });
                });
                M(document).on('click', '.downloadServe', function () {
                    M.ajaxFn({
                        url:  $.interfacePath.basic +'t/agency/ageementPdf',
                        type: 'get',
                        data: {
                            // bizType: M(this).attr('data-type')
                            bizType:"96"
                        },
                        dataType: 'json',
                        success: function (res) {
                            // console.log(res);
                            if ( res.success ) {
                                M.downloadFileXhr(res.data.endPath, '')
                            }else {
                                M.ui.waiting.creat({
                                    status:false,
                                    time:1000,
                                    text:res.message,
                                    hide:false
                                });
                            }
                        },
                        error: function (err) {
                            console.log('err+'+err)
                        }
                    });
                });
                M(document).on('click', '.preview', function () {
                    var userInfo = own.fetch('userInfo');
                    userInfo.fromPlatformContracts = true;
                    own.save('userInfo', userInfo);
                });
            },



        })(function () {
            M.platformContracts.init();
        });
    }
)
