require(['head', 'menu', 'base', 'tab', 'page','calendar', 'status'],
    function () {
        M.define('transferContracts', {
            head: M.ui.head.init(),
            init: function () {
                M.ui.menu.init({
                    index: [6, 1],
                    url: M.getNormalPath('getMenu.json', 4),
                    callback: function () {

                    }
                });
                this.base = M.static.init();
                this.getDate();
                this.getTableData(1);
                this.pageSize = 10;
            },

            getDate: function () {
                M.ui.tab.init({
                    index: 0,
                    button: $('.g-nav-tabs-li'),
                    panel: $('.g-tab-main'),
                    event: 'click',
                    currentClass: 'active',
                    url: null,
                    data: null,
                    callback: function () {
                    },
                    error: function () {
                    }
                });

                //----------------添加查询事件--------------------
                M('.ui-search-button').click(function(event) {
                    M.transferContracts.getTableData(1);
                });
            },

            getTableData: function (page) {

                /*日历*/
                var calenderStart = M.ui.calendar.init({
                    target: M('#js-calender-start'),
                    date: {
                        format: 'YYYY-MM-DD'
                    },
                    time: {
                        enabled: false
                    },
                    number: 1,
                    toggle: 1,
                    relative: {
                        type: 'stop'
                    },
                    tool: {
                        clear: true,
                        today: true
                    },
                    callback: function (that) {
                        M.delay(100, function () {
                            this.ops.relative.point = calenderStop;
                        }, this);
                    },
                    choose: function () {
                        //console.log(this);
                    }
                }, this);
                var calenderStop = M.ui.calendar.init({
                    target: M('#js-calender-stop'),
                    date: {
                        format: 'YYYY-MM-DD'
                    },
                    time: {
                        enabled: false
                    },
                    number: 1,
                    toggle: 2,
                    relative: {
                        type: 'start'
                    },
                    tool: {
                        clear: true,
                        today: true
                    },
                    callback: function (that) {
                        M.delay(100, function () {
                            this.ops.relative.point = calenderStart;
                            this.ops.date.min = calenderStart.ops.date.select;
                        }, this);
                    },
                    choose: function () {
                        //console.log(this);
                    }
                }, this);
             // var that = this;
                //pdf Print
               /* M(document).on('click', '.download', function () {
                    M.ajaxFn({
                        url:  $.interfacePath.basic +'t/autograph/filePath',
                        type: 'get',
                        data: {
                            signNo: M(this).parent().siblings().eq(0).html(),
                            bizType: '25'
                        },
                        dataType: 'json',
                        success: function (res) {
//                            console.log(res);
                            if ( res.success ) {
                                M.downloadFileXhr(res.data[0].autographFilePath, '')
                            }else {
                                M.ui.waiting.creat({
                                    status:false,
                                    time:1000,
                                    text:res.message,
                                    hide:false
                                });
                            }
                        },
                        error: function (err) {
                            console.log('err+'+err)
                        }
                    });
                });*/
                // var transferorCompanyName = M("#transferorCompanyName").val();转出方
                var transferorCompanyName="";
                var transfereeCompanyName = M('#transfereeCompanyName').val();
                var billNo = M('#billNo').val();
                var startTime = M('#js-calender-start').val();
                var endTime = M('#js-calender-stop').val();
                //查询债权转让列表
                M.ajaxFn({
                    url: M.interfacePath.bill +'t/debtsTransferApply/list',
                    typ: 'post',
                    data: {
                        "pageNum": page,
                        "pageSize": M.transferContracts.pageSize,
                        "transferorName": transferorCompanyName,
                        "transfereeName": transfereeCompanyName,
                        "batchNo": billNo,
                        "createDateStart":startTime,
                        "createDateEnd":endTime
                    },
                    datatype: 'json',
                    success: function (res) {
//                        console.log(res)
                        if (res.success) {
                            if(res.data == null || res.success == false || res.data.length == 0){
                                var noData = '<td colspan="5"><div class="noData"><img src="../../template/res/images/empty.png" alt=""><div class="col60 mar-top-10">暂无记录</div></div></td>';
                                M('.notice-tbody-content').html(noData);
                                M.transferContracts.getPage(res, page, M('#page'))
                                M('.pageTotal').html(res.total);
                                M('.pageCount').html(res.pageCount);
                            }else if(res.success && res.data.length!=0){
                                var str = '';
                                for (var i = 0; i < res.data.length; i++) {
                                    var item = res.data[i];
                                    str +=  '<tr>'+
                                                '<td align="center">'+item.batchNo+'</td>'+
                                                    '<td align="center" title="'+ item.transferorName +'">'+ item.transferorName +'</td>'+
                                                    '<td align="center" title="'+ item.transfereeName +'">'+item.transfereeName +'</td>'+
                                                    '<td align="center">'+ M.timetrans(item.signInDate) +'</td>'+
                                                '<td align="center">'+
                                                    '<a href="transferContract.html?id='+ item.id +'" class="preview" target="_blank">查看</a>'+
                                                    '<a href="javascript:;" class="download" data-id="'+ item.id +'" >下载</a>'+
                                                    '</td>'+
                                             '</tr>';

                                }

                                M('.notice-tbody-content').html(str);
                                M.transferContracts.getPage(res, page, M('#page'))
                                M('.pageTotal').html(res.total);
                                M('.pageCount').html(res.pageCount);
                                M('.download').unbind('click').bind('click', function () {
                                    M.ajaxFn({
                                        url:  $.interfacePath.basic +'t/autograph/filePath',
                                        type: 'get',
                                        data: {
                                            signNo: M(this).parent().siblings().eq(0).html(),
                                            bizType: '25'
                                        },
                                        dataType: 'json',
                                        success: function (res) {
//                            console.log(res);
                                            if ( res.success ) {
                                                M.downloadFileXhr(res.data[0].autographFilePath, '')
                                            }else {
                                                M.ui.waiting.creat({
                                                    status:false,
                                                    time:1000,
                                                    text:res.message,
                                                    hide:false
                                                });
                                            }
                                        },
                                        error: function (err) {
                                            console.log('err+'+err)
                                        }
                                    });
                                })

                            }
                        }else {
                            M.ui.waiting.creat({
                                status:false,
                                time:1000,
                                text: res.message,
                                hide:false,
                                callback: function () {

                                }
                            });
                        }
                    },
                    error: function (err) {
                        console.log(err)
                    }
                });
            },

            //分页
            getPage: function (data, page, obj) {
                M.ui.page.init({
                    container: obj[0],
                    total: data.total,
                    items: M.transferContracts.pageSize,
                    number: M.transferContracts.pageSize,
                    entries: 2,
                    isInput: true,
                    isText: false,
                    current: page - 1,
                    callback: function (that) {
                        M.transferContracts.getTableData(this.ops.current + 1)
                    }
                });
            }

        })(function () {
            M.transferContracts.init();
        });
    }
)
