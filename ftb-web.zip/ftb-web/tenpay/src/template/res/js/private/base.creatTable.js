/** 
 * 用途:表格自动生成
 * 作者:小马
 * 日期：2018/5/10
 * @import base.common.js 
 * @import base.scroll.js
 *
 * @wrapper	               		$object             (必选)最外层容器
 * @headText					[]					(必选)表头信息 		
 * @data						[]					(必选)数据
 * @prevEdit					Boolean				(选填)第一列是否有操作 							默认 false
 * @lastEdit					Boolean				(选填)最后一列是否有操作 							默认 false
 * @scroll						Boolean 			(选填)是否使用滚动条								默认false	
 * @key							[]					(必选)循环数据时，与表头对应的key	
 * @tableStyle					Number				(选填)表格风格 									默认4， (1：td边框+隔行变色，2：无隔行变色、td无边框，3：隔行变色+td边框，4：隔行变色、td无边框，5：table无边框+隔行变色)		
 * @allCheckCallback			Function			(选填)全选或全取消后回调	
 * @creatButton					Function			(必选)当lastEdit为true时有效，生成对应操作按钮
 * @buttonCallback				Function			(选填)操作按钮点击后回调函数
 */
;(function(M,window){
	M.ui.define('creatTables',function(){
		function CreatTable(ops,args){
			this.ops=ops;
			this.init(args);
		};
		CreatTable.prototype={
			constructor:CreatTable,
			init:function(args){
				this.creat(args);
				return this;
			},
			creat:function(args){
				this.ops.wrapper.css({
					'min-height':'300px'
				}).html(M.renderHTML({
					name:'img',
					proto: {
						src:'../base/images/loading.gif',
						style:{
							position: 'absolute',
							left: '50%',
							top: '50%'
						}
					}
				}))
				var data = this.ops.data,that = this;
				if(data !=''){
					this.ops.wrapper.html(this.creatHead())
					if(this.ops.scroll.enable){
						this.creatScroll(that)
					}
					M('#'+this.id).children('thead').find('input').off('click').on('click',function(){
						that.allCheck.call(this,that)
					})
					M('#'+this.id).find('button').off('click').on('click',function(){
						M.isFunction(that.ops.buttonCallback)&&that.ops.buttonCallback(M(this), that);
						//滚动条自适应
						if(that.scroll){
							that.scroll.refresh()
						}
					})
				}
			},
			creatHead: function(){
				this.id='g-table-'+M.now();
				var styles = this.ops.tableStyle;
				this.tabHead = M.renderHTML({
						name: 'table',
						proto:{
							style:{
								'width':'1200px'
							},
							'id':this.id,
							'class':styles ===1 ? 'g-table g-table-border' : styles === 2 ? 'g-table g-table-border g-table-border-bottom' : styles ===3? 'g-table g-table-border g-table-bg' : styles === 4 ? 'g-table g-table-border g-table-border-bottom g-table-bg' : styles === 5 ? 'g-table g-table-border-bottom g-table-bg' :''	
						},
						html:M.renderHTML({
							name:'thead',
							proto:{
								'class':''
							},
							html: M.renderHTML({
								name: 'tr',
								proto: {
									'class': ''
								},
								html: (this.creatHeadTd(this.ops.headText))
							})
						})+ this.creatBody()
				   })
				return this.tabHead
			},
			creatHeadTd: function(headData){
				var str = '';
				str += this.ops.prevEdit ? M.renderHTML({
							name:'th',
							proto:{
								'class':''
							},
							html:M.renderHTML({
								name: 'label',
								proto:{
									'class':'middle'
								},
								html: this.creatCheckBox()
							})
						}):''
				for (var i = 0; i < headData.length; i++) {
					str += M.renderHTML({
								name:'th',
								proto:{
									'class' : ''
								},
								html: headData[i]
							}) 
				}
				str += this.ops.lastEdit ? M.renderHTML({
								name: 'th',
								proto: {
									'class':''
								},
								html:'操作'
							}) : ''
				return str;
			},
			creatBody: function(){
				var dom = M.renderHTML({
							name: 'tbody',
							proto: {
								'class':''
							},
							html: this.creatBodyTr(this.ops.data)
						})
				return dom
			},
			creatBodyTr: function(data){
				for (var i = 0, str = ''; i < data.length; i++) {
					str += M.renderHTML({
						name: 'tr',
						proto:{
							'class': ''
						},
						html: (this.creatBodyTd(data[i]))
					})
				}
				return str;
			},
			creatBodyTd: function(data){
				var arr = this.ops.key,str = '',status = data.status
				str += this.ops.prevEdit ? M.renderHTML({
						name:'td',
						proto: {
							'class':''
						},
						html:this.creatCheckBox()
					}) : '';
				for (var i = 0; i < arr.length; i++) {
					str += M.renderHTML({
						name:'td',
						html:data[arr[i]]
					})
				}
				str += this.ops.lastEdit ? M.renderHTML({
						name:'td',
						proto: {
							'class':''
						},
						html:this.ops.lastEdit ? this.ops.creatButton(data.status) :''
					}) : '';
				return str;
			},
			creatCheckBox: function(){
				return M.renderHTML({
						name:'input',
						proto:{
							'class':'g-form-check',
							'type':'checkbox'
						}
						})+M.renderHTML({
							name:'span',
							proto: {
								'class':'g-form-lbl'
							}
						})
			},
			allCheck: function(that){
				var inputs = M('#'+that.id).children('tbody').find('input')
				if(M(this).attr('checked')){
					for(var i=0; i<inputs.length; i++){
						M(inputs[i]).attr('checked',true)
					}
				}else{
					for(var i=0; i<inputs.length; i++){
						M(inputs[i]).attr('checked',false)
					}
				}
				M.isFunction(that.ops.allCheckCallback)&&that.ops.allCheckCallback(inputs);
			},
			creatScroll:function(that){
				that.scroll = M.ui.scroll.init({
					scrollbar:{
						enabled:true,
						place:true,
						style:{
							marginLeft:0,
							marginRight:0,
							marginTop:0,
							marginBottom:0,
							size:5
						}	
					},
					direction:this.ops.scroll.direction,
					container:this.ops.wrapper,
					mouseWheelSpeed:50,
					callback:function(){},
					onScroll:function(){},
					resize:function(){}
				})
			}
		};
		return {
			defaults:{
				wrapper:null,
				headText: [],
				data: {},
				prevEdit: false,
				scroll: {
					enable: false,
					direction: 'x'
				},
				lastEdit: false,
				key: [],
				tableStyle:4,
				creatButton: function(status){},
				allCheckCallback: function(){},
				buttonCallback: function(o){}
			},	
			init:function(ops){
				return new CreatTable(M.extend(true,{},this.defaults,ops),[].slice.call(arguments,1));
			}
		};
	});
})(window.jQuery||window.Zepto||window.xQuery,window);